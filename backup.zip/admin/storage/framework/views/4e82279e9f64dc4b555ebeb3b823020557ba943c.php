

<?php $__env->startSection('content'); ?>

<?php

if($data->first_name && $data->last_name){
  $fullname = $data->first_name.' '.$data->last_name;
}elseif($data->first_name){
  $fullname = $data->first_name;
}elseif($data->last_name){
  $fullname = $data->last_name;
}
if($data->is_premium == 1)
{
  $premimum = "Yes";
}
else{
  $premimum = "No";
}
// if(!empty($data->profile_image))
// {
//     $profile = '<img height="60" width="60" src="'.env('DEFAULT_IMAGE_URL').$data->profile_image.'">';
// }
// else
// {
//     $profile = '<img height="60px;" width="60px;" src="'.asset('assets/dist/img/default.png').'">';
// }

?>
<section class="section">
  <div class="section-body">
    <div class="row mt-sm-4">
      <div class="col-12 col-md-12 col-lg-4">
        <div class="card author-box">
          <div class="card-body">
            <div class="author-box-center">
              <img alt="image" style="    width: 120px; height: 120px;" src="<?php if($data->profile_image): ?><?php echo e(env('DEFAULT_API_IMAGE_URL').$data->profile_image); ?><?php else: ?><?php echo e(asset('assets/dist/img/default.png')); ?><?php endif; ?>" class="rounded-circle author-box-picture user-profile">
              <div class="clearfix" style="margin-top: 20px;"> <button type="button" data-toggle="modal" data-target="#editModal" class="btn btn-primary btn-lg" >Edit Profile </button> </div>
              <div class="author-box-name" style="margin-top: 10px;">
                <h5><?php echo e($data->first_name); ?> <?php echo e($data->last_name); ?></h5>
              </div>
              <div class="author-box-job"></div>
            </div>
            
          </div>
        </div>
      </div>
      <input type="hidden" name="hidden_user_id" id="hidden_user_id" value="<?php echo e($data->user_id); ?>">

      <div class="col-12 col-md-12 col-lg-8">
        <div class="card">
          <div class="padding-20">
            <ul class="nav nav-tabs" id="myTab2" role="tablist">
              <li class="nav-item">
                <a class="nav-link active" id="home-tab2" data-toggle="tab" href="#about" role="tab" aria-selected="true">About</a>
              </li>
            </ul>
            <div class="tab-content tab-bordered" id="myTab3Content">
              <div class="tab-pane fade show active" id="about" role="tabpanel" aria-labelledby="home-tab2">
                <div class="row">
                  <div class="col-md-3 col-6 b-r">
                    <strong>First Name</strong>
                    <br>
                    <p class="text-muted"><?php echo e($data->first_name); ?></p>
                  </div>
                  <div class="col-md-3 col-6 b-r">
                    <strong>Last Name</strong>
                    <br>
                    <p class="text-muted"><?php echo e($data->last_name); ?></p>
                  </div>
                  <div class="col-md-3 col-6 b-r">
                    <strong>Is Premium?</strong>
                    <br>
                    <p class="text-muted"><?php echo e($premimum); ?></p>
                  </div>
                  <div class="col-md-3 col-6">
                    
                  </div>
                </div>
                
                
              </div>
              
            </div>
          </div>
        </div>
      </div>
      <div class="col-12 col-md-12 col-lg-12">
        <div class="card">
          <div class="padding-20">
            <ul class="nav nav-tabs" id="myTab2" role="tablist">
              <li class="nav-item">
                <a class="nav-link active" id="home-tab2" data-toggle="tab" href="#about" role="tab" aria-selected="true">Purchase History</a>
              </li>
            </ul>
            <br/>
            <div class="table-responsive">
              <table class="table table-striped" id="purchase-history-listing" style="width:100%;">
                <thead>
                  <tr>
                    <th>History ID </th>
                    <th>Course Title </th>
                    <th>Purchase Date</th>
                    <th>Price</th>            
                  </tr>
                </thead>
                <tbody>
                    
                
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>


      <div class="col-12 col-md-12 col-lg-12">
        <div class="card">
          <div class="padding-20">
            <ul class="nav nav-tabs" id="myTab2" role="tablist">
              <li class="nav-item">
                <a class="nav-link active" id="home-tab2" data-toggle="tab" href="#about" role="tab" aria-selected="true">Ticket History</a>
              </li>
            </ul>
            <br/>
            <div class="table-responsive">
              <table class="table table-striped" id="support-listing" style="width:100%;">
                <thead>
                  <tr>
                    <th>Ticket ID</th>
                    <th>User Name</th>
                    <th>Issue</th>
                    <th>Description</th>
                    <th>Closing text</th>
                    <th>Image</th>
                    <th>Status <br/></th>
                    <th>Action</th>
            
                  </tr>
                </thead>
                <tbody>
                  
                
                </tbody>
              </table>
            </div>


          </div>
        </div>
      </div>

    </div>
  </div>
</section>


<div class="modal fade" id="editModal" tabindex="-1" role="dialog" aria-labelledby="formModal"
          aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="formModal">Edit Profile Image</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
      <form name="edit_profile"  id="edit_profile">
      
          <input type="hidden" name="user_id" id="user_id" value="<?php echo e($data->user_id); ?>">
          <div class="form-group">
            <label>Profile Picture</label>
            <div class="input-group">
              <div class="input-group-prepend">
                <div class="input-group-text">
                  <i class="fas fa-list"></i>
                </div>
              </div>
                <input type="file" class="form-control" name="profile_image" id="profile_image">
              <br/>
            </div>
          </div>
          <input type="hidden" name="hdn_profile_image" id="hdn_profile_image" value="<?php echo e($data->profile_image); ?>">
          <div class="form-group">
            <p id="preview1" style="text-align: center;"><img src="<?php if($data->profile_image): ?><?php echo e(env('DEFAULT_API_IMAGE_URL').$data->profile_image); ?><?php else: ?><?php echo e(asset('assets/dist/img/default.png')); ?><?php endif; ?>" width="100" height="100" id="preview_img_1" style=" margin-right: 5px;"/></p>
          </div>
  
          <input type="submit" class="btn btn-primary m-t-15 waves-effect" value="Save" id="language_from_btn">
        </form>
      </div>
    </div>
  </div>
</div>

<div class="modal fade" id="viewSupportDetail" tabindex="-1" role="dialog" aria-labelledby="ModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="SupportTicketModalLabel"> Open Ticket </h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <form id="CloseSupportTicket" method="post" enctype="multipart">
      <?php echo e(csrf_field()); ?>

        <div class="modal-body">
          
            <div class="form-group">
            <label for="user_name">User Name</label>
            <input type="text"  class="form-control form-control-danger" placeholder="User Name" name="user_name" id="user_name" readonly>
          </div>

          <div class="form-group">
            <label for="issue">Issue</label>
            <input type="text"  class="form-control form-control-danger" placeholder="Issue" name="issue" id="issue" readonly>
          </div>

          <div class="form-group">
            <label for="description">Description</label>
            <textarea  class="form-control form-control-danger" placeholder="Description" name="description" id="description" readonly></textarea>
          </div>

          <div class="form-row"> 
            <div class="form-group col-md-6 ">
                <label for="image"> Image</label>
                <div id="photo_gallery" class="col-md-6 mt-1">
                </div>
            </div>
          </div>

          <div class="form-group">
            <label for="added_date">Added Date</label>
            <input type="text"  class="form-control form-control-danger" placeholder="Added Date" name="added_date" id="added_date" readonly>
          </div>

          <div class="form-group">
            <label for="close_text">Reply</label>
            <textarea  class="form-control form-control-danger" placeholder="Reply" name="close_text" id="close_text"></textarea>
          </div>

        </div>
        <div class="modal-footer">
          <input type="hidden" name="support_id" id="support_id" value="">
          <button type="submit" class="btn btn-success support_close">Resolve</button>
          <button type="button" class="btn btn-light" data-dismiss="modal">Close</button>
        </div>
      </form>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('pageSpecificJs'); ?>

<script src="<?php echo e(asset('assets/bundles/datatables/datatables.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/bundles/datatables/DataTables-1.10.16/js/dataTables.bootstrap4.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/bundles/jquery-ui/jquery-ui.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/page/datatables.js')); ?>"></script>
<script src="<?php echo e(asset('assets/bundles/izitoast/js/iziToast.min.js')); ?>"></script>

<script>
$(document).ready(function (){
  var dataTable = $('#user-listing').dataTable({
    'processing': true,
    'serverSide': true,
    'serverMethod': 'post',
    "order": [[ 0, "desc" ]],
    'columnDefs': [ {
          'targets': [0], /* column index */
          'orderable': false, /* true or false */
        }],
    'ajax': {
        'url':'<?php echo e(route("showUserList")); ?>',
        'data': function(data){
          data.is_premium = 2;
        }
    }
  });

  $(document).on('change', '#profile_image', function () {
    CheckFileExtention(this,'preview1');
  });

  var CheckFileExtention = function (input, cl) {

    if (input.files) {
        var allowedExtensions = /(\.jpg|\.jpeg|\.png)$/i;
        if (!allowedExtensions.exec(input.value)) {
            iziToast.error({
                title: 'Error!',
                message: 'Please upload file having extensions .jpeg/.jpg/.png only.',
                position: 'topRight'
            });
            input.value = '';
            return false;
        } else {
            if(cl.length > 0){
                var reader = new FileReader();

                reader.onload = function (e) {
                    $('#' + cl).html('<img src="'+e.target.result+'" width="100" height="100" id="preview_img_1" style=" margin-right: 5px;"/>');
                }

                reader.readAsDataURL(input.files[0]);
            }
        }
    }
  };

  if($("form[name='edit_profile']").length > 0){
    $("form[name='edit_profile']").validate({

      submitHandler: function (form) {
        $('.loader').show();
        $.ajax({
              url: '<?php echo e(route("updateUserProfile")); ?>',
              data: new FormData($('#edit_profile')[0]),
              type: 'POST',
              contentType: false,
              cache: false,
              processData: false,
              dataType : "json",
              success: function ( data ) {
                  $('.loader').hide();
                if(data.status == 1)
                {
                      if(data.user_profile_url){
                          $('.user-profile').attr('src',data.user_profile_url);
                      }
                      $('#editModal').modal('hide');

                  successmessage('Success', 'Admin profile update successfully');
                }
                else
                {
                  errormessage('Error', 'Admin profile update failed');
                }
              }
          });
      }
    });
  }

  var dataTable = $('#support-listing').dataTable({
        'processing': true,
        'serverSide': true,
        'serverMethod': 'post',
        "order": [[ 0, "desc" ]],
        'columnDefs': [ {
            'targets': [0], /* column index */
            'orderable': false, /* true or false */
            }],
        'ajax': {
            'url':'<?php echo e(route("showSupportList")); ?>',
            'data': function(data){
            data.status = 3;
            data.user_id = $('#hidden_user_id').val();
            }
        }
    });

    var dataTable = $('#purchase-history-listing').dataTable({
        'processing': true,
        'serverSide': true,
        'serverMethod': 'post',
        "order": [[ 0, "desc" ]],
        'columnDefs': [ {
            'targets': [0], /* column index */
            'orderable': false, /* true or false */
            }],
        'ajax': {
            'url':'<?php echo e(route("showPurchaseHistoryList")); ?>',
            'data': function(data){
            data.status = 1;
            data.user_id = $('#hidden_user_id').val();
            }
        }
    });

  $('#viewSupportDetail').on('hidden.bs.modal', function(e) {
      $("#CloseSupportTicket")[0].reset();
      var validator = $("#CloseSupportTicket").validate();
      validator.resetForm();
  });

  $(document).on("click", ".viewSupportDetail", function() {
      $('.loader').show();
      $('#support_id').val($(this).attr('data-id'));
      var support_id = $(this).attr('data-id');
      $.ajax({
          url: '<?php echo e(route("getSupportDataByID")); ?>',
          type: 'POST',
          data: {support_id:support_id},
          dataType: "json",
          cache: false,
          success: function (data) {
                $('.loader').hide();
                if(data.status == 1){
                    $('#SupportTicketModalLabel').text('Open Ticket');
                    $('.support_close').show();
                    $('#close_text').removeAttr('readonly');
                }else{
                    $('#SupportTicketModalLabel').text('Close Ticket');
                    $('.support_close').hide();
                    $('#close_text').attr('readonly',true);
                }

                $('#user_name').val(data.user_name);
                $('#issue').val(data.issue);
                $('#description').val(data.description);
                $('#close_text').val(data.close_text);
                $('#added_date').val(data.added_date);
                $('#photo_gallery').html('<div class=""><img src="'+data.image+'" width="150" height="150"/> </div>');
              
          },
          error: function (jqXHR, textStatus, errorThrown) {
              alert(errorThrown);
          }
      });
  });


  $("#CloseSupportTicket").validate({
      rules: {
        close_text:{
          required: true,
        },
      },
      messages: {
        close_text: {
          required: "Please Enter Close Reply",
        },
      }
  });

  $(document).on('submit', '#CloseSupportTicket', function (e) {
    e.preventDefault();
    
    var formdata = new FormData($("#CloseSupportTicket")[0]);
    $('.loader').show();
    $.ajax({
        url: '<?php echo e(route("CloseSupportTicket")); ?>',
        type: 'POST',
        data: formdata,
        dataType: "json",
        contentType: false,
        cache: false,
        processData: false,
        success: function (data) {
            $('.loader').hide();
            $('#viewSupportDetail').modal('hide');
            if (data.success == 1) {
                $('#support-listing').DataTable().ajax.reload(null, false);
                iziToast.success({
                    title: 'Success!',
                    message: data.message,
                    position: 'topRight'
                });
            } else {
                iziToast.error({
                    title: 'Error!',
                    message: data.message,
                    position: 'topRight'
                });
            }
        },
        error: function (jqXHR, textStatus, errorThrown) {
            alert(errorThrown);
        }
    });
  });

});
</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin_layouts/main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\learny-new\resources\views/admin/user/viewusers.blade.php ENDPATH**/ ?>