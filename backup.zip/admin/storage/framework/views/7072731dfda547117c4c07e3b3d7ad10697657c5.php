<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta name="description" content="">
  <meta name="author" content="">

  <title>Bubble</title>


  <link href="<?php echo e(asset('assets/css/app.min.css')); ?>" rel="stylesheet">
  <link href="<?php echo e(asset('assets/css/style.css')); ?>" rel="stylesheet">
  <link href="<?php echo e(asset('assets/css/components.css')); ?>" rel="stylesheet" type="text/css" />
  <link href="<?php echo e(asset('assets/css/custom.css')); ?>" rel="stylesheet">
  <link rel='shortcut icon' type='image/x-icon' href="<?php echo e(asset('assets/img/favicon.ico')); ?>" />
  <link rel="stylesheet" href="<?php echo e(asset('assets/bundles/sweetalert/css/sweetalert.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('assets/bundles/font-awesome/css/font-awesome.min.css')); ?>">
  <?php echo $__env->yieldContent('pageSpecificCss'); ?>

</head>

<body>
  <div class="loader"></div>
  <div id="app">
    <div class="main-wrapper main-wrapper-1">
      <div class="navbar-bg"></div>
      <nav class="navbar navbar-expand-lg main-navbar sticky">
        <div class="form-inline mr-auto">
          <ul class="navbar-nav mr-3">
            <li><a href="#" data-toggle="sidebar" class="nav-link nav-link-lg
									collapse-btn"> <i data-feather="align-justify"></i></a></li>
            <li><a href="#" class="nav-link nav-link-lg fullscreen-btn">
                <i data-feather="maximize"></i>
              </a>
            </li>
          </ul>
        </div>
        <?php
        $data = \App\Admin::first();
        ?>
        <ul class="navbar-nav navbar-right">
          <li class="dropdown"><a href="#" data-toggle="dropdown"
              class="nav-link dropdown-toggle nav-link-lg nav-link-user"> <img alt="image" src="<?php if($data): ?><?php echo e(url(env('DEFAULT_IMAGE_URL').$data['admin_profile'])); ?><?php else: ?><?php echo e(asset('assets/dist/img/default.png')); ?><?php endif; ?>"
                class="user-img-radious-style author-box-profile"> <span class="d-sm-none d-lg-inline-block"></span></a>
            <div class="dropdown-menu dropdown-menu-right pullDown">
              <div class="dropdown-title">Hello <?php echo e($data['username']); ?></div>
                <a href="<?php echo e(route('my-profile')); ?>" class="dropdown-item has-icon"> <i class="far
                      fa-user"></i> Profile
                </a>
                
              <div class="dropdown-divider"></div>
              <a href="<?php echo e(route('logout',['flag' => 0])); ?>" class="dropdown-item has-icon text-danger"> <i class="fas fa-sign-out-alt"></i>
                Logout
              </a>
            </div>
          </li>
        </ul>
      </nav>
      
  <?php echo $__env->make('admin_layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    
  <div class="main-content">
      <?php echo $__env->yieldContent('content'); ?>
  </div>

  <div class="modal fade" id="modal-video" tabindex="-1" role="dialog" aria-labelledby="myModalLabel1"
          aria-hidden="true">
    <div class="modal-dialog" role="document">
    <div class="modal-content">
        <div class="modal-header">
        <h5 class="modal-title" id="myModalLabel1"></h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
        </button>
        </div>
        <div class="modal-body videodiv">
        <video width="450" height="450" controls>
                        <source src="" type="video/mp4">
                </video>
        </div>
        <div class="modal-footer bg-whitesmoke br">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        </div>
    </div>
    </div>
</div>


  <footer class="main-footer">
    <div class="footer-left">
      <a href="#"><?php echo e(date('Y')); ?> &copy; Learny </a></a>
    </div>
    <div class="footer-right">
    </div>
  </footer>
</div>
</div>

<script src="<?php echo e(asset('assets/js/app.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/dist/js/jquery.validate.js')); ?>"></script>
<script src="<?php echo e(asset('assets/bundles/sweetalert/js/sweetalert.js')); ?>"></script>
<script type="text/javascript">
        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });
    </script>

    <?php echo $__env->yieldContent('pageSpecificJs'); ?>

    <script src="<?php echo e(asset('assets/js/scripts.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/custom.js')); ?>"></script>
</body>
</html><?php /**PATH /home/romsanapp/public_html/admin/resources/views/admin_layouts/main.blade.php ENDPATH**/ ?>