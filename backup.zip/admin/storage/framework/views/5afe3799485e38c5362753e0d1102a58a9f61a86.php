
<?php $__env->startSection('pageSpecificCss'); ?>
<link href="<?php echo e(asset('assets/bundles/datatables/datatables.min.css')); ?>" rel="stylesheet">
<link href="<?php echo e(asset('assets/bundles/datatables/DataTables-1.10.16/css/dataTables.bootstrap4.min.css')); ?>" rel="stylesheet">

<link href="<?php echo e(asset('assets/bundles/summernote/summernote-bs4.css')); ?>" rel="stylesheet">
<link href="<?php echo e(asset('assets/bundles/izitoast/css/iziToast.min.css')); ?>" rel="stylesheet">
<style type="text/css">
.custom-switch-input:checked ~ .custom-switch-indicator:before {
    left: calc(2rem + 1px);
}
.custom-switch-indicator:before {
    height: calc(2.25rem - 4px);
    width: calc(2.25rem - 4px);
}
.custom-switch-indicator {
    height: 2.25rem;
    width: 4.25rem;
}
</style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<section class="section">
  <div class="section-body">

<div class="row">
  <div class="col-12 col-md-12 col-lg-12">
    <div class="card">
      <div class="card-body">
        <div class="card-header">
          <h4><?php echo e($title); ?> Course</h4>
        </div>
        <div class="card-body">
            <form class="forms-sample" id="addUpdateCourse">
            <?php echo e(csrf_field()); ?>

 
            <div class="form-row">
                <div class="form-group col-md-12">
                  <label for="course_title">Course Title</label>
                  <input type="text"  name="course_title" class="form-control" id="course_title" placeholder="Course Title" value="<?php if($data): ?><?php echo e($data['title']); ?><?php endif; ?>">
                </div>
            </div>

            <div class="form-row">
              <div class="form-group col-md-12">
                <label for="course_description">Course Description</label>
                <textarea id="course_description" name="course_description">
                <?php if($data): ?><?php echo e($data['description']); ?><?php endif; ?>
                </textarea>
              </div>
            </div>

            <div class="form-row">
                <div class="form-group col-md-4">
                    <label for="author_id">Author</label>
                    <select class="form-control form-control-lg author_id" name="author_id">
                        <option value="">Select</option>
                        <?php $__currentLoopData = $authordata; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $authorval): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if ($data && $data['author_id'] == $authorval['author_id']) {
                            $selected = 'selected';
                            } else {
                            $selected = '';
                            } ?>
                            <option value="<?php echo e($authorval['author_id']); ?>" <?php echo e($selected); ?>><?php echo e($authorval['author_name']); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <div class="form-group col-md-4">
                    <label for="language_id">Language</label>
                    <select class="form-control form-control-lg language_id" name="language_id">
                        <option value="">Select</option>
                        <?php $__currentLoopData = $languagedata; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $languageval): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if ($data && $languageval['language_id'] == $data['language_id']) {
                            $selected = 'selected';
                            } else {
                            $selected = '';
                            } ?>
                            <option value="<?php echo e($languageval['language_id']); ?>" <?php echo e($selected); ?>><?php echo e($languageval['language_name']); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>

                <?php $selected = $selected1 = '';
                  if($data){ 
                    $duration = explode(' ',$data['duration']);
                    if(end($duration) == 'Minute'){
                      $selected = 'selected';
                    }
                    if(end($duration) == 'Hour'){
                      $selected1 = 'selected';
                    }
                  }?>

                <div class="form-group col-md-2">
                  <label for="course_duration">Course Duration</label>
                  <div class="input-group mb-3">
                    <input type="number" min="0" name="course_duration" class="form-control" id="course_duration" placeholder="Course Duration" value="<?php if($data): ?><?php echo e($duration[0]); ?><?php endif; ?>">
                    <div class="input-group-append">
                      <select id="duration_type" name="duration_type" class="form-control form-control-danger">
                        <option value="Minute" <?php echo e($selected); ?>>Minute</option>
                        <option value="Hour" <?php echo e($selected1); ?>>Hour</option>
                      </select>
                    </div>
                  </div>
                </div>

                <div class="form-group col-md-2">
                    <label for="price">Price</label>
                  <input type="number"  name="price" class="form-control" id="price" min="0" placeholder="Price" value="<?php if($data): ?><?php echo e($data['price']); ?><?php endif; ?>">
                </div>
            </div>

            <div class="form-row">
                <div class="form-group col-md-2">
                    <label for="course_img">Add Course Images</label>
                    <input type="file" name="course_image[]" id="course_image" class="form-control course_image" accept="image/png,image/jpg,image/jpeg,image/webp" multiple/>
                </div>
                <div id="photo_gallery" class="col-md-10 mt-4">
                    <?php if($data){
                        $course_img = explode(',',$data['course_image']);
                    ?>
                    <?php $__currentLoopData = $course_img; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if(!empty($val)): ?>
                        <div class="borderwrap" data-href="<?php if(!empty($val)): ?><?php echo e($val); ?><?php endif; ?>">
                            <div class="filenameupload"><img src="<?php if($val && !empty($val) ): ?><?php echo e(url(env('DEFAULT_API_IMAGE_URL').$val)); ?><?php endif; ?>" width="130" height="130">
                            <div class="middle"><i class="material-icons remove_img">cancel</i></div> 
                            </div>
                        </div>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                    <?php } ?>
                </div>
                <input type="hidden" name="hidden_course_image" id="hidden_course_image" value="<?php if($data): ?><?php echo e($data['course_image']); ?><?php endif; ?>">
            </div>

            <div class="form-row">
                <div class="form-group col-md-4">
                    <label for="preview_type">Preview video type</label>
                    <select class="form-control form-control-lg preview_type" name="preview_type" id="preview_type">
                        <option value="1">Upload Video</option>
                        <option value="2">Youtube URL</option>
                    </select>
                </div>
                <div class="form-group col-md-3 uploadVideoDiv">
                    <label for="preview_vid">Preview video</label>
                    <input type="file" name="preview_video" id="preview_video" class="form-control preview_video" accept="video/*" />
                    <div class="progress progress" style="height: 25px;margin:10px 0px;">
                        <div class="progress-bar" width="">0%</div>
                    </div>
                </div>
                <div id="video_gallery" class="col-md-3 mt-1 uploadVideoDiv">
                    <?php if($data){
                        $preview_vid = explode(',',$data['preview_video']);
                    ?>
                    <div class=""><video width="150" height="150" class="displayimg1" controls=""> <source src="<?php if($data && !empty($data->preview_video) ): ?><?php echo e(url(env('DEFAULT_API_IMAGE_URL').$data->preview_video)); ?><?php endif; ?>" type="video/mp4"> </video> </div>
                    <?php } ?>
                </div>
                <input type="hidden" name="hidden_preview_video" id="hidden_preview_video" value="<?php if($data): ?><?php echo e($data['preview_video']); ?><?php endif; ?>">
               
                <div class="form-group col-md-8 YoutubeDiv">
                    <label for="youtube_link">Youtube Link</label>
                    <input type="text"  name="youtube_link" class="form-control" id="youtube_link" placeholder="Youtube Link" value="<?php if($data): ?><?php echo e($data['preview_video']); ?><?php endif; ?>">
                </div>
            </div>
            <?php
                if($data){
                    $learning = explode(',',$data->learning);
                    $requirement = explode(',',$data->requirements);
                }
            ?>
            <div class="optionBox_learning">
                <div id="learningdiv" class="learningdiv">
                    <div class="form-group">
                        <label> Learning</label>
                        <div class="input-group mb-3">
                            <input type="text" class="form-control" value="<?php if($data): ?><?php echo e($learning[0]); ?><?php endif; ?>" name="learning[]" id="learning" placeholder="Learning" aria-label="">
                            <div class="input-group-append">                
                                <a class="btn btn-primary text-light add_learning"><i class="fa fa-plus"></i></a>
                            </div>
                        </div>
                    </div>
                </div>
                <?php if($data): ?>
                <?php $__currentLoopData = $learning; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $lval): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($key != 0): ?>
                    <div id="learningdiv" class="learningdiv">
                        <div class="form-group">
                            <div class="input-group mb-3">
                                <input type="text" class="form-control" value="<?php if($lval): ?><?php echo e($lval); ?><?php endif; ?>" name="learning[]" id="learning" placeholder="Learning" aria-label="">
                                <div class="input-group-append">                
                                    <a class="btn btn-danger text-light remove_learning"><i class="fa fa-minus"></i></a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
            </div>

            <div class="optionBox_requirement">
                <div id="requirementdiv" class="requirementdiv">
                    <div class="form-group">
                        <label> Requirement</label>
                        <div class="input-group mb-3">
                            <input type="text" class="form-control" value="<?php if($data): ?><?php echo e($requirement[0]); ?><?php endif; ?>" name="requirement[]" id="requirement" placeholder="Requirement" aria-label="">
                            <div class="input-group-append">                
                                <a class="btn btn-primary text-light add_requirement"><i class="fa fa-plus"></i></a>
                            </div>
                        </div>
                    </div>
                </div>
                <?php if($data): ?>
                <?php $__currentLoopData = $requirement; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $rval): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($key != 0): ?>
                        <div id="requirementdiv" class="requirementdiv">
                            <div class="form-group">
                                <label> Requirement</label>
                                <div class="input-group mb-3">
                                    <input type="text" class="form-control" value="<?php if($rval): ?><?php echo e($rval); ?><?php endif; ?>" name="requirement[]" id="requirement" placeholder="Requirement" aria-label="">
                                    <div class="input-group-append">                
                                        <a class="btn btn-danger text-light remove_requirement"><i class="fa fa-minus"></i></a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
            </div>
            <?php 
             $checked = '';
             $checked1 = '';
             $checked2 = '';
             if($data){
                if($data->is_featured == 1){
                    $checked = 'checked';
                }
                if($data->is_popular == 1){
                  $checked1 = 'checked';
                }
                if($data->is_bestseller == 1){
                  $checked2 = 'checked';
                }
            }
            ?>
            <div class="form-row">
                <div class="form-group col-md-3">
                  <label class="custom-switch">
                    <input type="checkbox" id="is_feature" name="is_feature" <?php echo e($checked); ?> class="custom-switch-input">
                    <span class="custom-switch-indicator"></span>
                    <span class="custom-switch-description">Is Featured</span>
                  </label>
                </div>
                <div class="form-group col-md-2">
                  <label class="custom-switch">
                    <input type="checkbox" id="is_popular" name="is_popular" <?php echo e($checked1); ?> class="custom-switch-input">
                    <span class="custom-switch-indicator"></span>
                    <span class="custom-switch-description">Is Popular</span>
                  </label>
                </div>
                <div class="form-group col-md-3">
                    <label class="custom-switch">
                      <input type="checkbox" id="is_bestseller" name="is_bestseller" <?php echo e($checked2); ?> class="custom-switch-input">
                      <span class="custom-switch-indicator"></span>
                      <span class="custom-switch-description">Is Bestseller</span>
                  </label>
                </div>
            </div>

            <input type="hidden" name="course_id" id="course_id" value="<?php if($data): ?><?php echo e($data['course_id']); ?><?php endif; ?>">
            <input type="hidden" name="action" id="action" value="<?php if($data): ?><?php echo e('update'); ?><?php else: ?><?php echo e('add'); ?><?php endif; ?>">
            <button type="submit" class="btn btn-primary mr-2 course_add">Submit</button>
            <a class="btn btn-light" href="<?php echo e(route('course/list')); ?>">Cancel</a>
          </form>
        </div>
      </div>
    </div>
  </div>

  </div>
</section>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('pageSpecificJs'); ?>

<script src="<?php echo e(asset('assets/bundles/datatables/datatables.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/bundles/datatables/DataTables-1.10.16/js/dataTables.bootstrap4.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/bundles/jquery-ui/jquery-ui.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/page/datatables.js')); ?>"></script>
<script src="<?php echo e(asset('assets/bundles/summernote/summernote-bs4.js')); ?>"></script>
<script src="<?php echo e(asset('assets/bundles/izitoast/js/iziToast.min.js')); ?>"></script>

<script>

  $(document).ready(function() {

    $("#course_description").summernote({
        height: 250,
        toolbar: [
            [ 'style', [ 'style' ] ],
            [ 'font', [ 'bold', 'italic', 'underline', 'clear'] ],
            [ 'fontname', [ 'fontname' ] ],
            [ 'fontsize', [ 'fontsize' ] ],
            [ 'color', [ 'color' ] ],
            [ 'para', [ 'ol', 'ul', 'paragraph', 'height' ] ],
            [ 'table', [ 'table' ] ],
            [ 'insert', [ 'link'] ],
            [ 'view', [ 'undo', 'redo', 'fullscreen', 'codeview', 'help' ] ]
        ],
        styleTags: [
          'p',
              { title: '', tag: '', className: 'summernote_p', value: '' },
        ],
    });
    $('.note-editing-area .note-editable p').attr("style","line-height:1");


    $("form").on('click', '.add_learning', function (e) {
        html='<div class="learningdiv"> <div class="form-group" >  <div class="input-group mb-3"> <input type="text" class="form-control" name="learning[]" id="learning" placeholder="" aria-label="" > <div class="input-group-append">   <a class="btn btn-danger text-light remove_learning"><i class="fa fa-minus"></i></a></div> </div> </div></div>';
     
      $('.learningdiv:last').after(html);

    });

    $("form").on('click', '.add_requirement', function (e) {
        html='<div class="requirementdiv"> <div class="form-group" >  <div class="input-group mb-3">  <input type="text" class="form-control" name="requirement[]" id="requirement" placeholder="" aria-label="" > <div class="input-group-append">   <a class="btn btn-danger text-light remove_requirement"><i class="fa fa-minus"></i></a></div> </div> </div></div>';
     
      $('.requirementdiv:last').after(html);

    });

    $('.optionBox_learning').on('click','.remove_learning',function() {
        $(this).parent().parent().parent().remove();
    })
    $('.optionBox_requirements').on('click','.remove_requirement',function() {
        $(this).parent().parent().parent().remove();
    })

    $('.YoutubeDiv').hide();
    $(document).on('change', '#preview_type', function (e) {
        var value = $(this).val();
        if(value == 1){
        $('.uploadVideoDiv').show();
        $('.YoutubeDiv').hide();
        }else{
        $('.uploadVideoDiv').hide();
        $('.YoutubeDiv').show();
        }
    });

    $(document).on('change', '#course_image', function() {
      imagesPreview(this, '#photo_gallery');
    });

    $(document).on('change', '#preview_video', function() {
      videoPreview(this, '#video_gallery');
    });

    var imagesPreview = function(input, placeToInsertImagePreview) {

        if (input.files) {
            var filesAmount = input.files.length;
            var allowedExtensions = /(\.jpg|\.jpeg|\.png|\.jfif|\.webp)$/i;
            for (i = 0; i < filesAmount; i++) {

                if(!allowedExtensions.exec(input.value)){
                iziToast.error({
                    title: 'Error!',
                    message: 'Please upload file having extensions .jpeg/.jpg/.png only.',
                    position: 'topRight'
                });
                input.value = '';
                return false;
                }else{

                var reader = new FileReader();

                reader.onload = function(event) {
                    $(placeToInsertImagePreview).append('<div class="borderwrap" data-href="'+event.target.result+'"><div class="filenameupload"><img src="'+event.target.result+'" width="130" height="130"> <div class="middle"><i class="material-icons remove_img">cancel</i></div> </div></div>');
                }

                reader.readAsDataURL(input.files[i]);
                }
            }
        }
    };

    var videoPreview = function(input, placeToInsertImagePreview) {

      if (input.files) {
        var filesAmount = input.files.length;
        var allowedExtensions = /(\.mp4|\.mpeg|\.mpg|\.mov|\.avi|\.3gp|\.f4v|\.webm|\.vlc)$/i;
        for (i = 0; i < filesAmount; i++) {

          if(!allowedExtensions.exec(input.value)){
            iziToast.error({
              title: 'Error!',
              message: 'Please upload correct file.',
              position: 'topRight'
            });
            input.value = '';
            return false;
          }else{

            $('.course_add').attr('disabled',true);
            var formdata = new FormData($("#addUpdateCourse")[0]);
            $.ajax({
                xhr: function() {
                var xhr = new window.XMLHttpRequest();
                xhr.upload.addEventListener("progress", function(evt) {
                    if (evt.lengthComputable) {
                    var percentComplete = ((evt.loaded / evt.total) * 100);
                    percentComplete = percentComplete.toFixed(2);
                    $(".progress-bar").width(percentComplete + '%');
                    $(".progress-bar").html(percentComplete + '%');
                    }
                }, false);
                    return xhr;
                },
                type: 'POST',
                url: '<?php echo e(route("UpdateCourseMedia")); ?>',
                data: formdata,
                contentType: false,
                cache: false,
                processData: false,
                dataType: "json",
                beforeSend: function() {
                    $(".progress-bar").width('0%');
                    $(placeToInsertImagePreview).html("");
                },
                error: function() {
                    $(placeToInsertImagePreview).html('<p style="color:#EA4335;">File upload failed, please try again.</p>');
                },
                success: function(data) {
                    if (data.success == 1) {
                        $('.course_add').attr('disabled',false);
                        $('#hidden_preview_video').val(data.course_video);
                        $(placeToInsertImagePreview).html('<div class=""><video width="150" height="150" class="displayimg1" controls=""> <source src="'+data.default_path+data.course_video+'" type="video/mp4"> </video> </div>');
                    } 
                }
            });
          }
        }
      }
    };

    $(document).on('click','.remove_img', function(){

      var img_len = $('.borderwrap').length-1;
      var p_img = $(this).closest("div").parent().parent().attr('data-href');
      $(this).closest("div").parent().parent().remove();

      var upload_img = $('#hidden_course_image').val();
      var temp = upload_img.replace(p_img+",",'');

      if(upload_img == temp){
        var temp = upload_img.replace(p_img,'');
      }
      $('#hidden_course_image').val(temp);
      $('#hidden_course_image').attr('value',temp);

    });

    $("#addUpdateCourse").validate({
      rules: {
        course_title: {
          required: true,
        },
        course_description: {
          required: true,
        },
        author_id: {
          required: true,
        },
        language_id: {
          required: true,
        },
        course_duration: {
          required: true,
        },
        price: {
          required: true,
        },
        "learning[]": {
            required: true,
        },
        "requirement[]": {
            required: true,
        }
      },
      messages: {
        course_title: {
          required: "Please Enter Course Title",
        },
        course_description: {
          required: "Please Enter Course Description",
        },
        author_id: {
          required: "Please Select Author",
        },
        language_id: {
          required: "Please Select Language",
        },
        course_duration: {
          required: "Please Enter Course Duration",
        },
        price: {
          required: "Please Enter Price",
        },
        "learning[]": {
          required: "Please Enter Learning",
        },
        "requirement[]": {
          required: "Please Enter Requirement",
        }
      },

    });

  $(document).on('submit', '#addUpdateCourse', function (e) {
      e.preventDefault();
      var formdata = new FormData($("#addUpdateCourse")[0]);
      $('.loader').show();
      $.ajax({
          url: '<?php echo e(route("addUpdateCourse")); ?>',
          type: 'POST',
          data: formdata,
          dataType: "json",
          contentType: false,
          cache: false,
          processData: false,
          success: function (data) {
              $('.loader').hide();
              if (data.success == 1) {
                window.location.href = '<?php echo e(route("course/list")); ?>';
                iziToast.success({
                  title: 'Success!',
                  message: data.message,
                  position: 'topRight'
                });
              } else {
                iziToast.error({
                  title: 'Error!',
                  message: data.message,
                  position: 'topRight'
                });
              }
          },
          error: function (jqXHR, textStatus, errorThrown) {
              alert(errorThrown);
          }
      });
    });
           
});

</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin_layouts/main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\learny\resources\views/admin/course/course_addupdate.blade.php ENDPATH**/ ?>