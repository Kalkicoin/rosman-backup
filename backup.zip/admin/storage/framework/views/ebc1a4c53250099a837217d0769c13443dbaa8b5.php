
<?php $__env->startSection('pageSpecificCss'); ?>
<link href="<?php echo e(asset('assets/bundles/datatables/datatables.min.css')); ?>" rel="stylesheet">
<link href="<?php echo e(asset('assets/bundles/datatables/DataTables-1.10.16/css/dataTables.bootstrap4.min.css')); ?>" rel="stylesheet">

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<section class="section">

    <div class="row ">
      
        <div class="col-xl-4 col-lg-4 col-md-4 col-sm-4 col-xs-12">
            <div class="card">
                <div class="card-statistic-4">
                    <div class="align-items-center justify-content-between">
                        <div class="row ">
                            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 pr-0 ">
                                <div class="card-content text-center">
                                    <h4 class="font-20 total_support" style="color: dodgerblue;"> <?php echo e($total_support); ?> </h4>
                                    <span class="badge badge-primary text-center">All</span>
                                </div>
                            </div>                            
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-xl-4 col-lg-4 col-md-4 col-sm-4 col-xs-12">
            <div class="card">
                <div class="card-statistic-4">
                    <div class="align-items-center justify-content-between">
                        <div class="row ">
                            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 pr-0 ">
                                <div class="card-content text-center">
                                    <h3 class="font-20 total_open_support" style="color: dodgerblue;"> <?php echo e($total_open_support); ?> </h3>
                                    <span class="badge badge-danger text-center">Open</span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-xl-4 col-lg-4 col-md-4 col-sm-4 col-xs-12">
            <div class="card">
                <div class="card-statistic-4">
                    <div class="align-items-center justify-content-between">
                        <div class="row ">
                            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 pr-0 ">
                                <div class="card-content text-center">
                                    <h3 class="font-20 total_close_support" style="color: dodgerblue;"> <?php echo e($total_close_support); ?> </h3>
                                    <span class="badge badge-success text-center">Close</span>
                                </div>
                            </div>                            
                        </div>
                    </div>
                </div>
            </div>
        </div>        
    </div>
  <div class="section-body">
      <div class="row">
        <div class="col-12">
          <div class="card">
            <div class="card-header">
              <h4>Support List </h4>
            </div>

            <div class="card-body">
         
              <div class="tab" role="tabpanel">
                <ul class="nav nav-pills border-b mb-0 p-3">
                    <li role="presentation" class="nav-item"><a class="nav-link pointer active" href="#Section1" aria-controls="home" role="tab" data-toggle="tab">All </a></li>
                    <li role="presentation" class="nav-item"><a class="nav-link pointer" href="#Section2" role="tab" data-toggle="tab">Open </a></li>
                    <li role="presentation" class="nav-item"><a class="nav-link pointer" href="#Section3" role="tab" data-toggle="tab">Close </a></li>
                </ul>
              <div class="tab-content tabs" id="home">
							
              <div role="tabpanel" class="tab-pane active" id="Section1">
           
                <div class="card-body">	
                 
                  <div class="table-responsive">
                      <table class="table table-striped" id="support-listing">
                        <thead>
                          <tr>
                            <th>Ticket ID </th>
                            <th>UserName</th>
                            <th>Issue</th>
                            <th>Description</th>
                            <th>Closing Text</th>
                            <th>Image</th>
                            <th>View Details</th>
                          </tr>
                        </thead>
                        <tbody>

                        </tbody>
                      </table>
                  </div>
                </div>
              </div>

              <div role="tabpanel" class="tab-pane" id="Section2">
                <div class="card-body">	
                  <div class="table-responsive">
                    <table class="table table-striped" id="open-support-listing" width="100%">
                      <thead>
                        <tr>
                            <th>Ticket ID </th>
                            <th>UserName</th>
                            <th>Issue</th>
                            <th>Description</th>
                            <th>Image</th>
                            <th>View Details</th>
                        </tr>
                      </thead>
                      <tbody>

                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
              
              <div role="tabpanel" class="tab-pane" id="Section3">
                <div class="card-body">	
                  <div class="table-responsive">
                    <table class="table table-striped" id="close-support-listing" width="100%">
                      <thead>
                        <tr>
                            <th>Ticket ID </th>
                            <th>UserName</th>
                            <th>Issue</th>
                            <th>Description</th>
                            <th>Closing Text</th>
                            <th>Image</th>
                            <th>View Details</th>
                        </tr>
                      </thead>
                      <tbody>

                      </tbody>
                    </table>
                  </div>
                </div>
              </div>

          </div>

        </div>
      </div>
    </div>
  </div>
</section>



<div class="modal fade" id="viewSupportDetail" tabindex="-1" role="dialog" aria-labelledby="ModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="SupportTicketModalLabel"> Open Ticket </h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <form id="CloseSupportTicket" method="post" enctype="multipart">
      <?php echo e(csrf_field()); ?>

        <div class="modal-body">
          
            <div class="form-group">
            <label for="user_name">User Name</label>
            <input type="text"  class="form-control form-control-danger" placeholder="User Name" name="user_name" id="user_name" readonly>
          </div>

          <div class="form-group">
            <label for="issue">Issue</label>
            <input type="text"  class="form-control form-control-danger" placeholder="Issue" name="issue" id="issue" readonly>
          </div>

          <div class="form-group">
            <label for="description">Description</label>
            <textarea  class="form-control form-control-danger" placeholder="Description" name="description" id="description" readonly></textarea>
          </div>

          <div class="form-row"> 
            <div class="form-group col-md-6 ">
                <label for="image"> Image</label>
                <div id="photo_gallery" class="col-md-6 mt-1">
                </div>
            </div>
          </div>

          <div class="form-group">
            <label for="added_date">Added Date</label>
            <input type="text"  class="form-control form-control-danger" placeholder="Added Date" name="added_date" id="added_date" readonly>
          </div>

          <div class="form-group">
            <label for="close_text">Reply</label>
            <textarea  class="form-control form-control-danger" placeholder="Reply" name="close_text" id="close_text"></textarea>
          </div>

        </div>
        <div class="modal-footer">
          <input type="hidden" name="support_id" id="support_id" value="">
          <button type="submit" class="btn btn-success support_close">Resolve</button>
          <button type="button" class="btn btn-light" data-dismiss="modal">Close</button>
        </div>
      </form>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('pageSpecificJs'); ?>

<script src="<?php echo e(asset('assets/bundles/datatables/datatables.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/bundles/datatables/DataTables-1.10.16/js/dataTables.bootstrap4.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/bundles/jquery-ui/jquery-ui.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/page/datatables.js')); ?>"></script>
<script src="<?php echo e(asset('assets/bundles/izitoast/js/iziToast.min.js')); ?>"></script>

<script>
$(document).ready(function (){
    var dataTable = $('#support-listing').dataTable({
        'processing': true,
        'serverSide': true,
        'serverMethod': 'post',
        "order": [[ 0, "desc" ]],
        'columnDefs': [ {
            'targets': [6], /* column index */
            'orderable': false, /* true or false */
            }],
        'ajax': {
            'url':'<?php echo e(route("showSupportList")); ?>',
            'data': function(data){
            data.status = 0;
            }
        }
    });

    var dataTable = $('#open-support-listing').dataTable({
        'processing': true,
        'serverSide': true,
        'serverMethod': 'post',
        "order": [[ 0, "desc" ]],
        'columnDefs': [ {
            'targets': [5], /* column index */
            'orderable': false, /* true or false */
            }],
        'ajax': {
            'url':'<?php echo e(route("showSupportList")); ?>',
            'data': function(data){
            data.status = 1;
            }
        }
    });

    var dataTable = $('#close-support-listing').dataTable({
        'processing': true,
        'serverSide': true,
        'serverMethod': 'post',
        "order": [[ 0, "desc" ]],
        'columnDefs': [ {
            'targets': [6], /* column index */
            'orderable': false, /* true or false */
            }],
        'ajax': {
            'url':'<?php echo e(route("showSupportList")); ?>',
            'data': function(data){
                // Read values
                data.status = 2;
            }
        }
    });

   
  $('#viewSupportDetail').on('hidden.bs.modal', function(e) {
      $("#CloseSupportTicket")[0].reset();
      var validator = $("#CloseSupportTicket").validate();
      validator.resetForm();
  });

  $(document).on("click", ".viewSupportDetail", function() {
      $('.loader').show();
      $('#support_id').val($(this).attr('data-id'));
      var support_id = $(this).attr('data-id');
      $.ajax({
          url: '<?php echo e(route("getSupportDataByID")); ?>',
          type: 'POST',
          data: {support_id:support_id},
          dataType: "json",
          cache: false,
          success: function (data) {
                $('.loader').hide();
                if(data.status == 1){
                    $('#SupportTicketModalLabel').text('Open Ticket');
                    $('.support_close').show();
                    $('#close_text').removeAttr('readonly');
                }else{
                    $('#SupportTicketModalLabel').text('Close Ticket');
                    $('.support_close').hide();
                    $('#close_text').attr('readonly',true);
                }

                $('#user_name').val(data.user_name);
                $('#issue').val(data.issue);
                $('#description').val(data.description);
                $('#close_text').val(data.close_text);
                $('#added_date').val(data.added_date);
                $('#photo_gallery').html('<div class=""><img src="'+data.image+'" width="150" height="150"/> </div>');
              
          },
          error: function (jqXHR, textStatus, errorThrown) {
              alert(errorThrown);
          }
      });
  });


  $("#CloseSupportTicket").validate({
      rules: {
        close_text:{
          required: true,
        },
      },
      messages: {
        close_text: {
          required: "Please Enter Close Reply",
        },
      }
  });

  $(document).on('submit', '#CloseSupportTicket', function (e) {
    e.preventDefault();
    
    var formdata = new FormData($("#CloseSupportTicket")[0]);
    $('.loader').show();
    $.ajax({
        url: '<?php echo e(route("CloseSupportTicket")); ?>',
        type: 'POST',
        data: formdata,
        dataType: "json",
        contentType: false,
        cache: false,
        processData: false,
        success: function (data) {
            $('.loader').hide();
            $('#viewSupportDetail').modal('hide');
            if (data.success == 1) {
                $('#support-listing').DataTable().ajax.reload(null, false);
                $('#open-support-listing').DataTable().ajax.reload(null, false);
                $('#close-support-listing').DataTable().ajax.reload(null, false);
                $('.total_support').text(data.total_support);
                $('.total_open_support').text(data.total_open_support);
                $('.total_close_support').text(data.total_close_support);
                iziToast.success({
                    title: 'Success!',
                    message: data.message,
                    position: 'topRight'
                });
            } else {
                iziToast.error({
                    title: 'Error!',
                    message: data.message,
                    position: 'topRight'
                });
            }
        },
        error: function (jqXHR, textStatus, errorThrown) {
            alert(errorThrown);
        }
    });
  });


});
</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin_layouts/main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\learny\resources\views/admin/support/support_list.blade.php ENDPATH**/ ?>