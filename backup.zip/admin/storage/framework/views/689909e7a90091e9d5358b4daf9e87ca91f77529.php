
<?php $__env->startSection('pageSpecificCss'); ?>
<link href="<?php echo e(asset('assets/bundles/datatables/datatables.min.css')); ?>" rel="stylesheet">
<link href="<?php echo e(asset('assets/bundles/datatables/DataTables-1.10.16/css/dataTables.bootstrap4.min.css')); ?>" rel="stylesheet">
<link href="<?php echo e(asset('assets/bundles/summernote/summernote-bs4.css')); ?>" rel="stylesheet">
<link href="<?php echo e(asset('assets/bundles/izitoast/css/iziToast.min.css')); ?>" rel="stylesheet">

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<section class="section">
  <div class="section-body">
        <div class="row">
            <div class="col-12">
                <div class="card">
                    <div class="card-header">
                        <h4>Author List (<span class="total_author"><?php echo e($total_author); ?></span>)</h4>
                    </div>
                   
                    <div class="card-body">	
                        <div class="pull-right">
                            <div class="buttons"> 
                                <button class="btn btn-primary text-light" data-toggle="modal" data-target="#authorModal" data-whatever="@mdo">Add Author</button>
                            </div>
                        </div>
                        <div class="table-responsive">
                            <table class="table table-striped" id="author-listing">
                                <thead>
                                <tr>
                                    <th>Profile</th>
                                    <th>Name</th>
                                    <th>Position</th>
                                    <th>Social Media</th>
                                    <th>On/Off Intro</th>
                                    <th>Action</th>
                                </tr>
                                </thead>
                                <tbody>

                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<div class="modal fade" id="authorModal" tabindex="-1" role="dialog" aria-labelledby="ModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg" role="document">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="ModalLabel"> Add Author </h5>
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
        <form id="addUpdateAuthor" method="post" enctype="multipart">
        <?php echo e(csrf_field()); ?>

          <div class="modal-body">
            <div class="form-row">
              <div class="form-group col-md-6">
                <label for="author_name">Author Name</label>
                <input id="author_name" name="author_name" type="text" class="form-control form-control-danger" placeholder="Enter Author Name">
              </div>
              <div class="form-group col-md-6">
                <label for="author_position">Author Position</label>
                <input id="author_position" name="author_position" type="text" class="form-control form-control-danger" placeholder="Enter Author Position">
              </div>
            </div>
            <div class="form-row">
              <div class="form-group col-md-12">
                <label for="about_author">About Author</label>
                <textarea placeholder="About Author" name="about_author" id="about_author"></textarea>
              </div>
            </div>

            <div class="form-row">
              <div class="col-md-4">
                <div class="form-group">
                    <label for="authorprofile">Profile Image</label>
                    <input type="file" class="form-control-file file-upload custom_image valid" id="author_image" name="author_image" aria-required="true" aria-invalid="false">
                    <label id="author_image-error" class="error image_error" for="author_image" style="display: none;"></label>
                    <div class="preview_authorimg mt-4"></div>
                </div>
              </div>
              <div class="col-md-8">
                <div class="form-row">
                  <div class="form-group col-md-6">
                    <label for="instagram_profile">Instagram Profile</label>
                    <input id="instagram_profile" name="instagram_profile" type="text" class="form-control form-control-danger" placeholder="Enter Instagram Profile">
                  </div>
                  <div class="form-group col-md-6">
                    <label for="facebook_profile">Facebook Profile</label>
                    <input id="facebook_profile" name="facebook_profile" type="text" class="form-control form-control-danger" placeholder="Enter Facebook Profile">
                  </div>
                </div>
                <div class="form-row">
                  <div class="form-group col-md-6">
                    <label for="youtube_profile">Youtube Profile</label>
                    <input id="youtube_profile" name="youtube_profile" type="text" class="form-control form-control-danger" placeholder="Enter Youtube Profile">
                  </div>
                  <div class="form-group col-md-6">
                    <label for="twitter_profile">Twitter Profile</label>
                    <input id="twitter_profile" name="twitter_profile" type="text" class="form-control form-control-danger" placeholder="Enter Twitter Profile">
                  </div>
                </div>
              </div>
            </div>

          </div>
          <div class="modal-footer">
              <input type="hidden" name="author_id" id="author_id" value="">
            <button type="submit" class="btn btn-success">Save</button>
            <button type="button" class="btn btn-light" data-dismiss="modal">Close</button>
          </div>
        </form>
      </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('pageSpecificJs'); ?>

<script src="<?php echo e(asset('assets/bundles/datatables/datatables.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/bundles/datatables/DataTables-1.10.16/js/dataTables.bootstrap4.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/bundles/jquery-ui/jquery-ui.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/page/datatables.js')); ?>"></script>
<script src="<?php echo e(asset('assets/bundles/izitoast/js/iziToast.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/bundles/summernote/summernote-bs4.js')); ?>"></script>

<script>
$(document).ready(function (){
  var dataTable = $('#author-listing').dataTable({
    'processing': true,
    'serverSide': true,
    'serverMethod': 'post',
    "order": [[ 0, "desc" ]],
    'columnDefs': [ {
          'targets': [3,4,5], /* column index */
          'orderable': false, /* true or false */
        }],
    'ajax': {
        'url':'<?php echo e(route("showAuthorList")); ?>',
        'data': function(data){
        }
    }
  });

  $("#about_author").summernote({
        height: 300,
        focus: true,
        toolbar: [
            [ 'style', [ 'style' ] ],
            [ 'font', [ 'bold', 'italic', 'underline', 'clear'] ],
            [ 'fontname', [ 'fontname' ] ],
            [ 'fontsize', [ 'fontsize' ] ],
            [ 'color', [ 'color' ] ],
            [ 'para', [ 'ol', 'ul', 'paragraph', 'height' ] ],
            [ 'table', [ 'table' ] ],
            [ 'insert', [ 'link'] ],
            [ 'view', [ 'undo', 'redo', 'help' ] ]
        ],
        styleTags: [
          'p',
              { title: '', tag: '', className: 'summernote_p', value: '' },
        ],
    });
    $('.note-editing-area .note-editable p').attr("style","line-height:1");

  $(document).on('change', '#author_image', function () {
    CheckFileExtention(this,'preview_authorimg');
  });

  var CheckFileExtention = function (input, cl) {

    if (input.files) {
        var allowedExtensions = /(\.jpg|\.jpeg|\.png)$/i;
        if (!allowedExtensions.exec(input.value)) {
            iziToast.error({
                title: 'Error!',
                message: 'Please upload file having extensions .jpeg/.jpg/.png only.',
                position: 'topRight'
              });
            input.value = '';
            return false;
        } else {
            if(cl.length > 0){
                var reader = new FileReader();

                reader.onload = function (e) {
                    $('.' + cl).html('<div class=""><img src="'+e.target.result+'" width="150" height="150"/> </div>');
                }

                reader.readAsDataURL(input.files[0]);
            }
        }
    }
  };

  $('#authorModal').on('shown.bs.modal', function() {
    $('#about_author').summernote();
  });

  $('#authorModal').on('hidden.bs.modal', function(e) {
      $("#addUpdateAuthor")[0].reset();
      $('.modal-title').text('Add Author');
      $('#author_id').val("");
      $('#about_author').summernote("code", "");
      var validator = $("#addUpdateAuthor").validate();
      validator.resetForm();
  });

  $("#author-listing").on("click", ".UpdateAuthor", function() {
      $('.loader').show();
      $('.modal-title').text('Edit Author');
      $('#author_id').val($(this).attr('data-id'));
      var author_id = $(this).attr('data-id');
      $.ajax({
          url: '<?php echo e(route("getAuthorByID")); ?>',
          type: 'POST',
          data: {author_id:author_id},
          dataType: "json",
          cache: false,
          success: function (data) {
              $('.loader').hide();
              $('#author_name').val(data.author_name);
              $('#author_position').val(data.author_position);
              $('#about_author').summernote("code", data.about);
              $('.preview_authorimg').html('<div class=""><img src="'+data.profile_image+'" width="150" height="150"/> </div>');
              $('#instagram_profile').val(data.instagram_profile);
              $('#facebook_profile').val(data.facebook_profile);
              $('#youtube_profile').val(data.youtube_profile);
              $('#twitter_profile').val(data.twitter_profile);
          },
          error: function (jqXHR, textStatus, errorThrown) {
              alert(errorThrown);
          }
      });
  });

  $("#addUpdateAuthor").validate({
      rules: {
        author_name:{
            required: true,
              remote: {
                  url: '<?php echo e(route("CheckExistAuthor")); ?>',
                  type: "post",
                  data: {
                      author_name: function () { return $("#author_name").val(); },
                      author_id: function () { return $("#author_id").val(); },
                  }
              }
          },
          author_position:{
            required: true,
          },
          about_author:{
            required: true,
          }, 
      },
      messages: {
        author_name: {
            required: "Please Enter Author Name",
            remote: "Author Name Already Exist.",
        },
        author_position: {
            required: "Please Enter Author Position",
        },
        about_author: {
            required: "Please Enter About Author",
        },
      }
  });

  $(document).on('submit', '#addUpdateAuthor', function (e) {
    e.preventDefault();
    
    var formdata = new FormData($("#addUpdateAuthor")[0]);
    $('.loader').show();
    $.ajax({
        url: '<?php echo e(route("addUpdateAuthor")); ?>',
        type: 'POST',
        data: formdata,
        dataType: "json",
        contentType: false,
        cache: false,
        processData: false,
        success: function (data) {
            $('.loader').hide();
            $('#authorModal').modal('hide');
            if (data.success == 1) {

              $('#author-listing').DataTable().ajax.reload(null, false);
              $('.total_author').text(data.total_author);
              iziToast.success({
                title: 'Success!',
                message: data.message,
                position: 'topRight'
              });
            } else {
              iziToast.error({
                title: 'Error!',
                message: data.message,
                position: 'topRight'
              });
            }
        },
        error: function (jqXHR, textStatus, errorThrown) {
            alert(errorThrown);
        }
    });
  });

  $(document).on('click', '.DeleteAuthor', function (e) {
    e.preventDefault();
    var author_id = $(this).attr('data-id');
    var text = 'You will not be able to recover Author data!';   
    var confirmButtonText = 'Yes, Delete it!';
    var btn = 'btn-danger';
    swal({
      title: "Are you sure?",
      text: text,
      type: "warning",
      showCancelButton: true,
      confirmButtonClass: btn,
      confirmButtonText: confirmButtonText,
      cancelButtonText: "No, cancel please!",
      closeOnConfirm: false,
      closeOnCancel: false
    },
    function(isConfirm){
        if (isConfirm){
            $('.loader').show();
            $.ajax({
                url: '<?php echo e(route("deleteAuthor")); ?>',
                type: 'POST',
                data: {"author_id":author_id},
                dataType: "json",
                cache: false,
                success: function (data) {
                    $('.loader').hide();
                    $('#author-listing').DataTable().ajax.reload(null, false);
                    $('.total_author').text(data.total_author);
                    if (data.success == 1) {
                      swal("Confirm!", "Author has been deleted!", "success");
                    } else {
                      swal("Confirm!", "Author has not been deleted!", "error");
                    }
                },
                error: function (jqXHR, textStatus, errorThrown) {
                    alert(errorThrown);
                }
            });
          } else {
          swal("Cancelled", "Your imaginary file is safe :)", "error");
        }
      });
  });

  $(document).on('click', '#changeAuthorIntroStatus', function (e) {
    e.preventDefault();
    var author_id = $(this).attr('data-id');
    var status = $(this).attr('data-status');
    if(status == 1){
      status = 0;
    }else{
      status = 1;
    }
    var text = 'You will not be able to recover Author data!';   
    var confirmButtonText = 'Yes, Change Author Intro Status!';
    var btn = 'btn-danger';
    swal({
      title: "Are you sure?",
      text: text,
      type: "warning",
      showCancelButton: true,
      confirmButtonClass: btn,
      confirmButtonText: confirmButtonText,
      cancelButtonText: "No, cancel please!",
      closeOnConfirm: false,
      closeOnCancel: false
    },
    function(isConfirm){
        if (isConfirm){
            $('.loader').show();
            $.ajax({
                url: '<?php echo e(route("changeAuthorIntroStatus")); ?>',
                type: 'POST',
                data: {"author_id":author_id,"status":status},
                dataType: "json",
                cache: false,
                success: function (data) {
                    $('.loader').hide();
                    $('#author-listing').DataTable().ajax.reload(null, false);
                    $('.total_author').text(data.total_author);
                    if (data.success == 1) {
                      swal("Confirm!", "Author Intro Status has been changed!", "success");
                    } else {
                      swal("Confirm!", "Author Intro Status has not been changed!", "error");
                    }
                },
                error: function (jqXHR, textStatus, errorThrown) {
                    alert(errorThrown);
                }
            });
          } else {
          swal("Cancelled", "Your imaginary file is safe :)", "error");
        }
      });
  });

});
</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin_layouts/main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\learny\resources\views/admin/author/author_list.blade.php ENDPATH**/ ?>