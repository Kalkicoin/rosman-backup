
<?php $__env->startSection('pageSpecificCss'); ?>
<link href="<?php echo e(asset('assets/bundles/datatables/datatables.min.css')); ?>" rel="stylesheet">
<link href="<?php echo e(asset('assets/bundles/datatables/DataTables-1.10.16/css/dataTables.bootstrap4.min.css')); ?>" rel="stylesheet">

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<section class="section">
  <div class="section-body">
      <div class="row">
        <div class="col-12">
          <div class="card">
            <div class="card-header">
              <h4>PurchaseHistory List </h4>
            </div>

            <div class="card-body">
         
            <div class="card-body">	
                 
                 <div class="table-responsive">
                     <table class="table table-striped" id="purchasehistory-listing">
                       <thead>
                         <tr>
                            <th>History ID </th>
                            <th>Course Title </th>
                            <th>UserName</th>
                            <th>Purchase Date</th>
                            <th>Price</th>
                         </tr>
                       </thead>
                       <tbody>

                       </tbody>
                     </table>
                 </div>
               </div>
      </div>
    </div>
  </div>
</section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('pageSpecificJs'); ?>

<script src="<?php echo e(asset('assets/bundles/datatables/datatables.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/bundles/datatables/DataTables-1.10.16/js/dataTables.bootstrap4.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/bundles/jquery-ui/jquery-ui.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/page/datatables.js')); ?>"></script>
<script src="<?php echo e(asset('assets/bundles/izitoast/js/iziToast.min.js')); ?>"></script>

<script>
$(document).ready(function (){
    var dataTable = $('#purchasehistory-listing').dataTable({
        'processing': true,
        'serverSide': true,
        'serverMethod': 'post',
        "order": [[ 0, "desc" ]],
        'columnDefs': [ {
            'targets': [0], /* column index */
            'orderable': false, /* true or false */
            }],
        'ajax': {
            'url':'<?php echo e(route("showPurchaseHistoryList")); ?>',
            'data': function(data){
              data.status = 0;
            }
        }
    });
});
</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin_layouts/main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\learny\resources\views/admin/purchasehistory/purchasehistory_list.blade.php ENDPATH**/ ?>