
<?php $__env->startSection('pageSpecificCss'); ?>
<link href="<?php echo e(asset('assets/bundles/datatables/datatables.min.css')); ?>" rel="stylesheet">
<link href="<?php echo e(asset('assets/bundles/datatables/DataTables-1.10.16/css/dataTables.bootstrap4.min.css')); ?>" rel="stylesheet">
<link href="<?php echo e(asset('assets/bundles/summernote/summernote-bs4.css')); ?>" rel="stylesheet">
<link href="<?php echo e(asset('assets/bundles/izitoast/css/iziToast.min.css')); ?>" rel="stylesheet">

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<section class="section">
  <div class="section-body">
        <div class="row">
            <div class="col-12">
                <div class="card">
                    <div class="card-header">
                        <h4>Feed List (<span class="total_feed"><?php echo e($total_feed); ?></span>)</h4>
                    </div>
                   
                    <div class="card-body">	
                        <div class="pull-right">
                            <div class="buttons"> 
                                <button class="btn btn-primary text-light" data-toggle="modal" data-target="#feedModal" data-whatever="@mdo">Add Feed</button>
                            </div>
                        </div>
                        <div class="table-responsive">
                            <table class="table table-striped" id="feed-listing">
                                <thead>
                                <tr>
                                    <th>Author</th>
                                    <th>Descriptinon</th>
                                    <th>Content</th>
                                    <th>Action</th>
                                </tr>
                                </thead>
                                <tbody>

                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<div class="modal fade" id="feedModal" tabindex="-1" role="dialog" aria-labelledby="ModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="ModalLabel"> Add Feed </h5>
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
        <form id="addUpdateFeed" method="post" enctype="multipart">
        <?php echo e(csrf_field()); ?>

          <div class="modal-body">
            <div class="form-group">
              <label for="author_id">Select Author</label>
              <select id="author_id" name="author_id" class="form-control form-control-danger">
                <option value="">--Select--</option>
                <?php $__currentLoopData = $authorData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($val->author_id); ?>"><?php echo e($val->author_name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </select>
            </div>

            <div class="form-group">
              <label for="content_type">Content type</label>
              <select id="content_type" name="content_type" class="form-control form-control-danger">
                <option value="1" selected>Image or Video</option>
                <option value="2">text</option>
              </select>
            </div>

            <div class="form-group content_media_div">
              <label for="content_media">Image or Video</label>
              <input type="file" class="form-control-file file-upload custom_image valid" id="content_media" name="content_media" aria-required="true" aria-invalid="false">
              <div class="progress progress" style="height: 25px;margin:10px 0px;">
                <div class="progress-bar" width="">0%</div>
              </div>
              <div class="preview_media mt-4"></div> 
            </div>
            <input type="hidden" name="hidden_feed_video" id="hidden_feed_video" value="">
            <div class="form-group content_text_div">
              <label for="content_text">Content</label>
              <textarea placeholder="Content" name="content_text" id="content_text"></textarea>
            </div>

            <!-- <div class="form-group">
              <label for="description_type">Description type</label>
              <select id="description_type" name="description_type" class="form-control form-control-danger">
                <option value="1" selected>Image or Video</option>
                <option value="2">text</option>
              </select>
            </div> -->

            <!-- <div class="form-group description_media_div">
              <label for="description_media">Image or Video</label>
              <input type="file" class="form-control-file file-upload custom_image valid" id="description_media" name="description_media" aria-required="true" aria-invalid="false">
              <label id="description_media-error" class="error image_error" for="description_media" style="display: none;"></label>
              <div class="preview_description_media mt-4"></div> 
            </div> -->

            <div class="form-group description_div">
              <label for="description">Description</label>
              <textarea placeholder="Content" name="description" id="description"></textarea>
            </div>
          </div>
          <div class="modal-footer">
              <input type="hidden" name="feed_id" id="feed_id" value="">
            <button type="submit" class="btn btn-success addFeedbtn">Save</button>
            <button type="button" class="btn btn-light" data-dismiss="modal">Close</button>
          </div>
        </form>
      </div>
    </div>
  </div>

  <div class="modal fade" id="feedContentViewModal" tabindex="-1" role="dialog" aria-labelledby="feedContentViewModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-lg" role="document">
    <div class="modal-content ">
      <div class="modal-header">
        <h5 class="modal-title" id="feedContentViewModalLabel">Preview Content</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">×</span>
        </button>
      </div>
      <div class="modal-body">
        <div id="ContentPreview">

        </div>
      </div>
     
    </div>
  </div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('pageSpecificJs'); ?>

<script src="<?php echo e(asset('assets/bundles/datatables/datatables.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/bundles/datatables/DataTables-1.10.16/js/dataTables.bootstrap4.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/bundles/jquery-ui/jquery-ui.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/page/datatables.js')); ?>"></script>
<script src="<?php echo e(asset('assets/bundles/izitoast/js/iziToast.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/bundles/summernote/summernote-bs4.js')); ?>"></script>

<script>
$(document).ready(function (){
  var dataTable = $('#feed-listing').dataTable({
    'processing': true,
    'serverSide': true,
    'serverMethod': 'post',
    "order": [[ 0, "desc" ]],
    'columnDefs': [ {
          'targets': [3], /* column index */
          'orderable': false, /* true or false */
        }],
    'ajax': {
        'url':'<?php echo e(route("showFeedList")); ?>',
        'data': function(data){
        }
    }
  });

  $("#content_text").summernote({
        height: 250,
        toolbar: [
            [ 'style', [ 'style' ] ],
            [ 'font', [ 'bold', 'italic', 'underline', 'clear'] ],
            [ 'fontname', [ 'fontname' ] ],
            [ 'fontsize', [ 'fontsize' ] ],
            [ 'color', [ 'color' ] ],
            [ 'para', [ 'ol', 'ul', 'paragraph', 'height' ] ],
            [ 'table', [ 'table' ] ],
            [ 'insert', [ 'link'] ],
            [ 'view', [ 'undo', 'redo', 'help' ] ]
        ],
        styleTags: [
          'p',
              { title: '', tag: '', className: 'summernote_p', value: '' },
        ],
  });
  $('.note-editing-area .note-editable p').attr("style","line-height:1");

  $("#description").summernote({
        height: 250,
        toolbar: [
            [ 'style', [ 'style' ] ],
            [ 'font', [ 'bold', 'italic', 'underline', 'clear'] ],
            [ 'fontname', [ 'fontname' ] ],
            [ 'fontsize', [ 'fontsize' ] ],
            [ 'color', [ 'color' ] ],
            [ 'para', [ 'ol', 'ul', 'paragraph', 'height' ] ],
            [ 'table', [ 'table' ] ],
            [ 'insert', [ 'link'] ],
            [ 'view', [ 'undo', 'redo', 'help' ] ]
        ],
        styleTags: [
          'p',
              { title: '', tag: '', className: 'summernote_p', value: '' },
        ],
  });

  $("#content_text2").summernote({
        height: 250,
        toolbar: [
            [ 'style', [ 'style' ] ],
            [ 'font', [ 'bold', 'italic', 'underline', 'clear'] ],
            [ 'fontname', [ 'fontname' ] ],
            [ 'fontsize', [ 'fontsize' ] ],
            [ 'color', [ 'color' ] ],
            [ 'para', [ 'ol', 'ul', 'paragraph', 'height' ] ],
            [ 'table', [ 'table' ] ],
            [ 'insert', [ 'link'] ],
            [ 'view', [ 'undo', 'redo', 'help' ] ]
        ],
        styleTags: [
          'p',
              { title: '', tag: '', className: 'summernote_p', value: '' },
        ],
  });
  
  $(document).on('change', '#content_media', function () {
    CheckFileExtention(this,'preview_media');
  });

  $(document).on('change', '#description_media', function () {
    CheckFileExtention(this,'preview_description_media');
  });

  var CheckFileExtention = function (input, cl) {
    if (input.files) {
        var allowedExtensions = /(\.jpg|\.jpeg|\.png|\.mp4|\.mpeg|\.mpg|\.mov|\.avi|\.3gp|\.f4v|\.webm|\.vlc)$/i;
        var validImageTypes = ['image/gif', 'image/jpeg', 'image/png'];
        var file = input.files[0];
        var fileType = file["type"];
        if (!allowedExtensions.exec(input.value)) {
            iziToast.error({
                title: 'Error!',
                message: 'Please upload Image and Video File only.',
                position: 'topRight'
              });
            input.value = '';
            return false;
        } else {
            if(cl.length > 0){
              
                var formdata = new FormData($("#addUpdateFeed")[0]);
                $('.addFeedbtn').attr('disabled',true);
                  $.ajax({
                      xhr: function() {
                        var xhr = new window.XMLHttpRequest();
                        xhr.upload.addEventListener("progress", function(evt) {
                          if (evt.lengthComputable) {
                            var percentComplete = ((evt.loaded / evt.total) * 100);
                            percentComplete = percentComplete.toFixed(2);
                            $(".progress-bar").width(percentComplete + '%');
                            $(".progress-bar").html(percentComplete + '%');
                          }
                        }, false);
                        return xhr;
                      },
                      type: 'POST',
                      url: '<?php echo e(route("UpdateFeedMedia")); ?>',
                      data: formdata,
                      contentType: false,
                      cache: false,
                      processData: false,
                      dataType: "json",
                      beforeSend: function() {
                        $(".progress-bar").width('0%');
                        $('.' + cl).html("");
                      },
                      error: function() {
                        $('.' + cl).html('<p style="color:#EA4335;">File upload failed, please try again.</p>');
                      },
                      success: function(data) {
                        if (data.success == 1) {
                          $('.addFeedbtn').attr('disabled',false);
                          $('#hidden_feed_video').val(data.feed_video);
                          if (!validImageTypes.includes(fileType)) {
                            $('.' + cl).html('<div class=""><video width="150" height="150" class="displayimg1" controls=""> <source src="'+data.default_path+data.feed_video+'" type="video/mp4"> </video> </div>');
                          }else{
                            $('.' + cl).html('<div class=""><img src="'+data.default_path+data.feed_video+'" width="150" height="150"/> </div>');
                          }
                        } 
                      }
                  });

                  //   var reader = new FileReader();
                //   reader.onload = function (e) {
                //     $('.' + cl).html('<div class=""><img src="'+e.target.result+'" width="150" height="150"/> </div>');
                //       // if (!validImageTypes.includes(fileType)) {
                //       //   $('.' + cl).html('<div class=""><video width="150" height="150" class="displayimg1" controls=""> <source src="'+e.target.result+'" type="video/mp4"> </video> </div>');
                //       // }else{
                //       //   $('.' + cl).html('<div class=""><img src="'+e.target.result+'" width="150" height="150"/> </div>');
                //       // }
                //   }

                //   reader.readAsDataURL(input.files[0]);

                
                $('.loader').hide();
            }
        }
    }
  };
  $('.content_text_div').hide();
  $(document).on('change', '#content_type', function (e) {
    var value = $(this).val();
    if(value == 1){
      $('.content_media_div').show();
      $('.description_div').show();
      $('.content_text_div').hide();
    }else{
      $('.content_media_div').hide();
      $('.description_div').hide();
      $('.content_text_div').show();
    }
  });

  // $(document).on('change', '#description_type', function (e) {
  //   var value = $(this).val();
  //   if(value == 1){
  //     $('.description_media_div').show();
  //     $('.description_text_div').hide();
  //   }else{
  //     $('.description_media_div').hide();
  //     $('.description_text_div').show();
  //   }
  // });

  $('#feedModal').on('hidden.bs.modal', function(e) {
      $("#addUpdateFeed")[0].reset();
      $('.modal-title').text('Add Feed');
      $('#feed_id').val("");
      $('.content_media_div').show();
      $('.description_div').show();
      $('.content_text_div').hide();
      $('.preview_media').html('');
      $('#description').summernote("code", "");
      $('#content_text').summernote("code", "");
      $(".progress-bar").width('0%');
      $(".progress-bar").html('0%');
      var validator = $("#addUpdateFeed").validate();
      validator.resetForm();
  });

  $("#feed-listing").on("click", "#feedContentView", function() {
      $('.loader').show();
      var feed_id = $(this).attr('data-id');
      $.ajax({
          url: '<?php echo e(route("getFeedDataByID")); ?>',
          type: 'POST',
          data: {feed_id:feed_id},
          dataType: "json",
          cache: false,
          success: function (data) {
              $('.loader').hide();
              if(data.content_type == 1){
                var fileExtension = (data.content).substr(((data.content).lastIndexOf('.') + 1));
                var validImageTypes = ['gif', 'jpeg', 'png', 'jpg', 'webp'];
                if (!validImageTypes.includes(fileExtension)) {
                  $('#ContentPreview').html('<video width="100%" height="auto" class="displayimg1" controls=""> <source src="'+data.content+'" type="video/mp4"> </video>');
                }else{
                  $('#ContentPreview').html('<img src="'+data.content+'" width="100%" height="auto">');
                }
              }else{
                $('#ContentPreview').html('<textarea class="form-control" id="content_text2"></textarea>');
                $('#content_text2').summernote("code", data.content);
              }
          },
          error: function (jqXHR, textStatus, errorThrown) {
              alert(errorThrown);
          }
      });
      
  });

  $("#feed-listing").on("click", ".UpdateFeed", function() {
      $('.loader').show();
      $('.modal-title').text('Edit Feed');
      $('#feed_id').val($(this).attr('data-id'));
      var feed_id = $(this).attr('data-id');
      $.ajax({
          url: '<?php echo e(route("getFeedDataByID")); ?>',
          type: 'POST',
          data: {feed_id:feed_id},
          dataType: "json",
          cache: false,
          success: function (data) {
              $('.loader').hide();
              $('#author_id').val(data.author_id);
              $('#content_type').val(data.content_type);
              if(data.content_type == 1){
                $('.content_media_div').show();
                $('.description_div').show();
                $('.content_text_div').hide();
                var fileExtension = (data.content).substr(((data.content).lastIndexOf('.') + 1));
                var validImageTypes = ['gif', 'jpeg', 'png', 'jpg', 'webp'];
                if (!validImageTypes.includes(fileExtension)) {
                  $('.preview_media').html('<video width="150" height="150" class="displayimg1" controls=""> <source src="'+data.content+'" type="video/mp4"> </video>');
                }else{
                  $('.preview_media').html('<img src="'+data.content+'" width="150" height="150">');
                }
                $('#description').summernote("code", data.description);

              }else{
                $('.content_media_div').hide();
                $('.description_div').hide();
                $('.content_text_div').show();
                $('#content_text').summernote("code", data.content);
              }            
              
          },
          error: function (jqXHR, textStatus, errorThrown) {
              alert(errorThrown);
          }
      });
  });

  $("#addUpdateFeed").validate({
      rules: {
        feed_name:{
            required: true,
          },
          feed_position:{
            required: true,
          },
          about_feed:{
            required: true,
          }, 
      },
      messages: {
        feed_name: {
            required: "Please Enter Feed Name",
        },
        feed_position: {
            required: "Please Enter Feed Position",
        },
        about_feed: {
            required: "Please Enter About Feed",
        },
      }
  });

  $(document).on('submit', '#addUpdateFeed', function (e) {
    e.preventDefault();
    
    var formdata = new FormData($("#addUpdateFeed")[0]);
    $('.loader').show();
    $.ajax({
        url: '<?php echo e(route("addUpdateFeed")); ?>',
        type: 'POST',
        data: formdata,
        dataType: "json",
        contentType: false,
        cache: false,
        processData: false,
        success: function (data) {
            $('.loader').hide();
            $('#feedModal').modal('hide');
            if (data.success == 1) {

              $('#feed-listing').DataTable().ajax.reload(null, false);
              $('.total_feed').text(data.total_feed);
              iziToast.success({
                title: 'Success!',
                message: data.message,
                position: 'topRight'
              });
            } else {
              iziToast.error({
                title: 'Error!',
                message: data.message,
                position: 'topRight'
              });
            }
        },
        error: function (jqXHR, textStatus, errorThrown) {
            alert(errorThrown);
        }
    });
  });

  $(document).on('click', '.DeleteFeed', function (e) {
    e.preventDefault();
    var feed_id = $(this).attr('data-id');
    var text = 'You will not be able to recover Feed data!';   
    var confirmButtonText = 'Yes, Delete it!';
    var btn = 'btn-danger';
    swal({
      title: "Are you sure?",
      text: text,
      type: "warning",
      showCancelButton: true,
      confirmButtonClass: btn,
      confirmButtonText: confirmButtonText,
      cancelButtonText: "No, cancel please!",
      closeOnConfirm: false,
      closeOnCancel: false
    },
    function(isConfirm){
        if (isConfirm){
            $('.loader').show();
            $.ajax({
                url: '<?php echo e(route("deleteFeed")); ?>',
                type: 'POST',
                data: {"feed_id":feed_id},
                dataType: "json",
                cache: false,
                success: function (data) {
                    $('.loader').hide();
                    $('#feed-listing').DataTable().ajax.reload(null, false);
                    $('.total_feed').text(data.total_feed);
                    if (data.success == 1) {
                      swal("Confirm!", "Feed has been deleted!", "success");
                    } else {
                      swal("Confirm!", "Feed has not been deleted!", "error");
                    }
                },
                error: function (jqXHR, textStatus, errorThrown) {
                    alert(errorThrown);
                }
            });
          } else {
          swal("Cancelled", "Your imaginary file is safe :)", "error");
        }
      });
  });

});
</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin_layouts/main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\learny\resources\views/admin/feed/feed_list.blade.php ENDPATH**/ ?>