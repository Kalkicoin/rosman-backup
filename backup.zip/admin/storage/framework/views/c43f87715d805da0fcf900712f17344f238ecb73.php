
<?php $__env->startSection('pageSpecificCss'); ?>
<link href="<?php echo e(asset('assets/bundles/datatables/datatables.min.css')); ?>" rel="stylesheet">
<link href="<?php echo e(asset('assets/bundles/datatables/DataTables-1.10.16/css/dataTables.bootstrap4.min.css')); ?>" rel="stylesheet">
<link href="<?php echo e(asset('assets/bundles/summernote/summernote-bs4.css')); ?>" rel="stylesheet">
<link href="<?php echo e(asset('assets/bundles/izitoast/css/iziToast.min.css')); ?>" rel="stylesheet">

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<section class="section">

  <div class="section-body">
    <div class="row">
      <div class="col-12 col-md-12 col-lg-12">
        <div class="card">
          <div class="card-body">
            <div class="form-group">
              <label for="course_id">Select Course</label>
              <select id="searchByCourseId" name="search_course_id" class="form-control form-control-danger">
                <option value="">--Select Course--</option>
                <?php $__currentLoopData = $courseData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($lectureData && $lectureData->course_id == $val->course_id){
                  $selected = 'selected';
                }else{
                  $selected = '';
                } ?>
                <option value="<?php echo e($val->course_id); ?>" <?php echo e($selected); ?>><?php echo e($val->title); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </select>
            </div>

            <div class="form-group">
              <label for="section_id">Select Section</label>
              <select id="searchBySectionId" name="search_section_id" class="form-control form-control-danger">
                <option value="">--Select Section--</option>
                <?php $__currentLoopData = $sectionData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($lectureData && $lectureData->section_id == $val->section_id){
                  $selected = 'selected';
                }else{
                  $selected = '';
                } ?>
                <option value="<?php echo e($val->section_id); ?>" <?php echo e($selected); ?>><?php echo e($val->title); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </select>
            </div>
          </div>
        </div>
      </div>
    </div>            
  </div>
  <div class="section-body">
      <div class="row">
        <div class="col-12">
          <div class="card">
            <div class="card-header">
              <h4>Lecture List (<span class="total_lecture"><?php echo e($total_lecture); ?></span>)</h4>
            </div>

            <div class="card-body">
              <div class="pull-right">
                <div class="buttons"> 
                    <button class="btn btn-primary text-light" data-toggle="modal" data-target="#addLectureModal" data-whatever="@mdo">Add Lecture</button>
                </div>
              </div>
              <div class="tab" role="tabpanel">
              <ul class="nav nav-pills border-b mb-0 p-3">
								<li role="presentation" class="nav-item"><a class="nav-link pointer active" href="#Section1" aria-controls="home" role="tab" data-toggle="tab">Video <span class="badge badge-transparent total_video_lecture"><?php echo e($total_video_lecture); ?></span></a></li>
								<li role="presentation" class="nav-item"><a class="nav-link pointer" href="#Section2" role="tab" data-toggle="tab">Article <span class="badge badge-transparent total_article_lecture"><?php echo e($total_article_lecture); ?></span></a></li>
							</ul>
              <div class="tab-content tabs" id="home">
							
              <div role="tabpanel" class="tab-pane active" id="Section1">
                <div class="card-body">	
                  <div class="table-responsive">
                      <table class="table table-striped" id="video-lecture-listing">
                        <thead>
                          <tr>
                            <th>Course Name </th>
                            <th>Section</th>
                            <th>Title</th>
                            <th>Video Type</th>
                            <th>Video Preview</th>
                            <th>Duration</th>
                            <th>Action</th>
                          </tr>
                        </thead>
                        <tbody>

                        </tbody>
                      </table>
                  </div>
                </div>
              </div>

              <div role="tabpanel" class="tab-pane" id="Section2">
                <div class="card-body">	
                  <div class="table-responsive">
                    <table class="table table-striped" id="article-lecture-listing" width="100%">
                      <thead>
                        <tr>
                          <th>Course Name </th>
                          <th>Section</th>
                          <th>Title</th>
                          <th>Content</th>
                          <th>Action</th>
                        </tr>
                      </thead>
                      <tbody>

                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>


<div class="modal fade" id="addLectureModal" tabindex="-1" role="dialog" aria-labelledby="ModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="ModalLabel"> Add Lecture </h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <form id="addUpdateLecture" method="post" enctype="multipart">
      <?php echo e(csrf_field()); ?>

        <div class="modal-body">
          
          <div class="form-group">
            <label for="course_id">Select Course</label>
            <select id="course_id" name="course_id" class="form-control form-control-danger">
              <option value="">--Select Course--</option>
              <?php $__currentLoopData = $courseData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <option value="<?php echo e($val->course_id); ?>"><?php echo e($val->title); ?></option>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
          </div>

          <div class="form-group">
            <label for="section_id">Select Section</label>
            <select id="section_id" name="section_id" class="form-control form-control-danger">
              <option value="">--Select Section--</option>
              <?php $__currentLoopData = $sectionData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <option value="<?php echo e($val->section_id); ?>"><?php echo e($val->title); ?></option>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
          </div>
            
          <div class="form-group">
            <label for="lecture_title">Title</label>
            <input type="text"  class="form-control form-control-danger" placeholder="Lecture Title" name="lecture_title" id="lecture_title">
          </div>

          <div class="form-group">
            <label for="lecture_type">Lecture Type</label>
            <select id="lecture_type" name="lecture_type" class="form-control form-control-danger">
              <option value="1">Video</option>
              <option value="2">Article</option>
            </select>
          </div>

          <div class="form-group articleType">
              <label for="lecture_content">Content</label>
              <textarea placeholder="Content" name="lecture_content" id="lecture_content"></textarea>
            </div>

          <div class="form-group VideoType">
            <label for="video_type">Video Type</label>
            <select id="video_type" name="video_type" class="form-control form-control-danger">
              <option value="1">Upload Video</option>
              <option value="2">Youtube URL</option>
            </select>
          </div>
          <div class="form-row"> 
            <div class="form-group col-md-6 uploadVideoDiv">
                <label for="preview_vid">Preview Video</label>
                <input type="file" name="preview_video" id="preview_video" class="form-control preview_video" accept="video/*" />
                <div class="progress progress" style="height: 25px;margin:10px 0px;">
                    <div class="progress-bar" width="">0%</div>
                </div>
            </div>
            <div id="video_gallery" class="col-md-6 mt-1 uploadVideoDiv">

            </div>
            <input type="hidden" name="hidden_preview_video" id="hidden_preview_video" value="">
          </div>
          <div class="form-group YoutubeDiv">
              <label for="youtube_link">Youtube Link</label>
              <input type="text"  name="youtube_link" class="form-control" id="youtube_link" placeholder="Youtube Link" value="">
          </div>

          <div class="form-group VideoType">
            <label for="duration">Video Duration</label>
            <div class="input-group mb-3">
              <input type="number" min="0" name="duration" class="form-control" id="duration" placeholder="Lecture Duration" value="">
              <div class="input-group-append">
                <select id="duration_type" name="duration_type" class="form-control form-control-danger">
                  <option value="Minute">Minute</option>
                  <option value="Hour">Hour</option>
                </select>
              </div>
            </div>
          </div>

        </div>
        <div class="modal-footer">
          <input type="hidden" name="lecture_id" id="lecture_id" value="">
          <button type="submit" class="btn btn-success lecture_add">Save</button>
          <button type="button" class="btn btn-light" data-dismiss="modal">Close</button>
        </div>
      </form>
    </div>
  </div>
</div>

<div class="modal fade" id="modal-video" tabindex="-1" role="dialog" aria-labelledby="myModalLabel1" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
        <div class="modal-header">
        <h5 class="modal-title" id="myModalLabel1"></h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
        </button>
        </div>
        <div class="modal-body videodiv text-center">
        	<video width="300" height="300" controls>
					<source src="" type="video/mp4">
			</video>
        </div>
        <div class="modal-footer bg-whitesmoke br">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        </div>
    </div>
  </div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('pageSpecificJs'); ?>

<script src="<?php echo e(asset('assets/bundles/datatables/datatables.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/bundles/datatables/DataTables-1.10.16/js/dataTables.bootstrap4.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/bundles/jquery-ui/jquery-ui.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/page/datatables.js')); ?>"></script>
<script src="<?php echo e(asset('assets/bundles/izitoast/js/iziToast.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/bundles/summernote/summernote-bs4.js')); ?>"></script>

<script>
$(document).ready(function (){
  var videoDataTable = $('#video-lecture-listing').dataTable({
    'procesing': true,
    'serverSide': true,
    'serverMethod': 'post',
    "order": [[ 0, "desc" ]],
    'columnDefs': [ {
        'targets': [6], /* column index */
        'orderable': false, /* true or false */
      }],
    'ajax': {
        'url':'<?php echo e(route("showLectureList")); ?>',
        'data': function(data){
          data.lecture_type = 1;
          data.course_id = $('#searchByCourseId').val();
          data.section_id = $('#searchBySectionId').val();
        }
    }
  });  

  var articleDataTable = $('#article-lecture-listing').dataTable({
    'procesing': true,
    'serverSide': true,
    'serverMethod': 'post',
    "order": [[ 0, "desc" ]],
    'columnDefs': [ {
          'targets': [4], /* column index */
          'orderable': false, /* true or false */
        }],
    'ajax': {
        'url':'<?php echo e(route("showLectureList")); ?>',
        'data': function(data){
          data.lecture_type = 2;
          data.course_id = $('#searchByCourseId').val();
          data.section_id = $('#searchBySectionId').val();
        }
    }
  }); 

  $('#modal-video').on('hidden.bs.modal', function (e) {
      $(".videodiv video")[0].pause(); 
  });

  $(document).on("click", "#playvideomdl", function() {
      var src = $(this).attr('data-src');
      $('.videodiv video source').attr('src',src );
      $(".videodiv video")[0].load();
  });

  $(document).on('change', '#searchByCourseId', function (e) {
    $('#video-lecture-listing').DataTable().ajax.reload(null, false);
    $('#article-lecture-listing').DataTable().ajax.reload(null, false);
  });

  $(document).on('change', '#searchBySectionId', function (e) {
    $('#video-lecture-listing').DataTable().ajax.reload(null, false);
    $('#article-lecture-listing').DataTable().ajax.reload(null, false);
  });

  $("#lecture_content").summernote({
    height: 250,
        toolbar: [
            [ 'style', [ 'style' ] ],
            [ 'font', [ 'bold', 'italic', 'underline', 'clear'] ],
            [ 'fontname', [ 'fontname' ] ],
            [ 'fontsize', [ 'fontsize' ] ],
            [ 'color', [ 'color' ] ],
            [ 'para', [ 'ol', 'ul', 'paragraph', 'height' ] ],
            [ 'table', [ 'table' ] ],
            [ 'insert', [ 'link'] ],
            [ 'view', [ 'undo', 'redo', 'help' ] ]
        ],
        styleTags: [
          'p',
              { title: '', tag: '', className: 'summernote_p', value: '' },
        ],
  });
  $('.note-editing-area .note-editable p').attr("style","line-height:1");
  
  $('.articleType').hide();
  $('.YoutubeDiv').hide();

  $(document).on('change', '#lecture_type', function (e) {
      var value = $(this).val();
      if(value == 2){
        $('.articleType').show();
        $('.uploadVideoDiv').hide();
        $('.YoutubeDiv').hide();
        $('.VideoType').hide();
      }else{
        $('.articleType').hide();
        $('.uploadVideoDiv').show();
        $('.YoutubeDiv').hide();
        $('.VideoType').show();
      }
  });

  $(document).on('change', '#video_type', function (e) {
      var value = $(this).val();
      if(value == 1){
      $('.uploadVideoDiv').show();
      $('.YoutubeDiv').hide();
      }else{
      $('.uploadVideoDiv').hide();
      $('.YoutubeDiv').show();
      }
  });

  $(document).on('change', '#preview_video', function() {
    videoPreview(this, '#video_gallery');
  });


  var videoPreview = function(input, placeToInsertImagePreview) {

  if (input.files) {
    var filesAmount = input.files.length;
    var allowedExtensions = /(\.mp4|\.mpeg|\.mpg|\.mov|\.avi|\.3gp|\.f4v|\.webm|\.vlc)$/i;
    for (i = 0; i < filesAmount; i++) {

      if(!allowedExtensions.exec(input.value)){
        iziToast.error({
          title: 'Error!',
          message: 'Please upload correct file.',
          position: 'topRight'
        });
        input.value = '';
        return false;
      }else{

        $('.lecture_add').attr('disabled',true);
        var formdata = new FormData($("#addUpdateLecture")[0]);
        $.ajax({
            xhr: function() {
            var xhr = new window.XMLHttpRequest();
            xhr.upload.addEventListener("progress", function(evt) {
                if (evt.lengthComputable) {
                var percentComplete = ((evt.loaded / evt.total) * 100);
                percentComplete = percentComplete.toFixed(2);
                $(".progress-bar").width(percentComplete + '%');
                $(".progress-bar").html(percentComplete + '%');
                }
            }, false);
                return xhr;
            },
            type: 'POST',
            url: '<?php echo e(route("UpdateLectureMedia")); ?>',
            data: formdata,
            contentType: false,
            cache: false,
            processData: false,
            dataType: "json",
            beforeSend: function() {
                $(".progress-bar").width('0%');
                $(placeToInsertImagePreview).html("");
            },
            error: function() {
                $(placeToInsertImagePreview).html('<p style="color:#EA4335;">File upload failed, please try again.</p>');
            },
            success: function(data) {
                if (data.success == 1) {
                    $('.lecture_add').attr('disabled',false);
                    $('#hidden_preview_video').val(data.lecture_video);
                    $(placeToInsertImagePreview).html('<div class=""><video width="150" height="150" class="displayimg1" controls=""> <source src="'+data.default_path+data.lecture_video+'" type="video/mp4"> </video> </div>');
                } 
            }
        });
      }
    }
  }
  };


  $('#addLectureModal').on('hidden.bs.modal', function(e) {
      $("#addUpdateLecture")[0].reset();
      $('.articleType').hide();
      $('.uploadVideoDiv').show();
      $('.YoutubeDiv').hide();
      $('.VideoType').show();
      $('#lecture_content').summernote("code", "");
      $(".progress-bar").width('0%');
      $(".progress-bar").html('0%');
      var validator = $("#addUpdateLecture").validate();
      validator.resetForm();
  });

  $(document).on("click", ".UpdateLecture", function() {
      $('.loader').show();
      $('.modal-title').text('Edit Lecture');
      $('#lecture_id').val($(this).attr('data-id'));
      var lecture_id = $(this).attr('data-id');
      $.ajax({
          url: '<?php echo e(route("getLectureDataByID")); ?>',
          type: 'POST',
          data: {lecture_id:lecture_id},
          dataType: "json",
          cache: false,
          success: function (data) {
              $('.loader').hide();
              $('#course_id').val(data.course_id);
              $('#section_id').val(data.section_id);
              $('#lecture_title').val(data.title);
              $('#duration').val(data.duration);
              $('#duration_type').val(data.duration_type);
              $('#lecture_type').val(data.lecture_type);
              if(data.lecture_type == 1){
                $('.articleType').hide();
                $('.uploadVideoDiv').show();
                $('.YoutubeDiv').hide();
                $('.VideoType').show();
                if(data.video_type == 1){
                  $('.uploadVideoDiv').show();
                  $('.YoutubeDiv').hide();
                }else{
                  $('.uploadVideoDiv').hide();
                  $('.YoutubeDiv').show();
                }
                
                $('#video_type').val(data.video_type);
                $('#video_gallery').html('<video width="150" height="150" class="displayimg1" controls=""> <source src="'+data.preview_video+'" type="video/mp4"> </video>');    
                $('#hidden_preview_video').val(data.preview_video);   
                $('#youtube_link').val(data.preview_video);

              }else{
              
                $('.articleType').show();
                $('.uploadVideoDiv').hide();
                $('.YoutubeDiv').hide();
                $('.VideoType').hide();      
                $('#lecture_content').summernote("code", data.content);
  
              }            
              
          },
          error: function (jqXHR, textStatus, errorThrown) {
              alert(errorThrown);
          }
      });
  });


  $("#addUpdateLecture").validate({
      rules: {
        lecture_title:{
          required: true,
        },
        preview_video:{
          required: true,
        },
        youtube_link:{
          required: true,
        },
        lecture_content:{
          required: true,
        },
        duration:{
          required: true,
        },
      },
      messages: {
        lecture_title: {
          required: "Please Enter Lecture Title",
        },
        preview_video: {
          required: "Please Upload Video",
        },
        youtube_link: {
          required: "Please Enter Youtube URL",
        },
        lecture_content: {
          required: "Please Enter Content",
        },
        duration: {
          required: "Please Enter Duration",
        },
      }
  });

  $(document).on('submit', '#addUpdateLecture', function (e) {
    e.preventDefault();
    
    var formdata = new FormData($("#addUpdateLecture")[0]);
    $('.loader').show();
    $.ajax({
        url: '<?php echo e(route("addUpdateLecture")); ?>',
        type: 'POST',
        data: formdata,
        dataType: "json",
        contentType: false,
        cache: false,
        processData: false,
        success: function (data) {
            $('.loader').hide();
            $('#addLectureModal').modal('hide');
            if (data.success == 1) {
              $('#video-lecture-listing').DataTable().ajax.reload(null, false);
              $('#article-lecture-listing').DataTable().ajax.reload(null, false);
              $('.total_lecture').text(data.total_lecture);
              $('.total_video_lecture').text(data.total_video_lecture);
              $('.total_article_lecture').text(data.total_article_lecture);
              iziToast.success({
                title: 'Success!',
                message: data.message,
                position: 'topRight'
              });
            } else {
              iziToast.error({
                title: 'Error!',
                message: data.message,
                position: 'topRight'
              });
            }
        },
        error: function (jqXHR, textStatus, errorThrown) {
            alert(errorThrown);
        }
    });
  });

  $(document).on('click', '.DeleteLecture', function (e) {
    e.preventDefault();
    var lecture_id = $(this).attr('data-id');
    var text = 'You will not be able to recover Lecture data!';   
    var confirmButtonText = 'Yes, Delete it!';
    var btn = 'btn-danger';
    swal({
      title: "Are you sure?",
      text: text,
      type: "warning",
      showCancelButton: true,
      confirmButtonClass: btn,
      confirmButtonText: confirmButtonText,
      cancelButtonText: "No, cancel please!",
      closeOnConfirm: false,
      closeOnCancel: false
    },
    function(isConfirm){
        if (isConfirm){
            $('.loader').show();
            $.ajax({
                url: '<?php echo e(route("deleteLecture")); ?>',
                type: 'POST',
                data: {"lecture_id":lecture_id},
                dataType: "json",
                cache: false,
                success: function (data) {
                    $('.loader').hide();
                    $('#video-lecture-listing').DataTable().ajax.reload(null, false);
                    $('#article-lecture-listing').DataTable().ajax.reload(null, false);
                    $('.total_lecture').text(data.total_lecture);
                    $('.total_video_lecture').text(data.total_video_lecture);
                    $('.total_article_lecture').text(data.total_article_lecture);
                    if (data.success == 1) {
                      swal("Confirm!", "Lecture has been deleted!", "success");
                    } else {
                      swal("Confirm!", "Lecture has not been deleted!", "error");
                    }
                },
                error: function (jqXHR, textStatus, errorThrown) {
                    alert(errorThrown);
                }
            });
          } else {
          swal("Cancelled", "Your imaginary file is safe :)", "error");
        }
      });
  });

});
</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin_layouts/main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\learny\resources\views/admin/lecture/lecture_list.blade.php ENDPATH**/ ?>