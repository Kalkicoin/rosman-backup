

<?php $__env->startSection('content'); ?>

<section class="section">
  <div class="row">

    <div class="col-md-6">
      <div class="card">
        
        <div class="card-body padd-0 text-center">
          <div class="card-avatar style-2">
            <?php
              if(!empty($data['user_profile']))
              {
                ?>
                <img height="150px" width="150px" src="<?php echo e(url(env('DEFAULT_IMAGE_URL').$data['user_profile'])); ?>" class="rounded-circle author-box-picture mb-2" alt="">
                <?php
              }
              else
              {
                ?>
                <img height="150px" width="150px" src="<?php echo e(asset('assets/dist/img/default.png')); ?>" class="rounded-circle author-box-picture mb-2" alt="">
                <?php
              }
            ?>
            
          </div>
          <p class="card-small-text"><?php if($data['is_verify'] == 1): ?><?php echo e(Verified); ?><?php endif; ?></p>
          <h5 class="font-normal mrg-bot-0 font-18 card-title"><?php echo e($data['full_name']); ?></h5>
          <h6 class="font-normal mrg-bot-0 font-15 card-title"><?php echo e($data['user_name']); ?></h6>
          <p class="card-small-text"><?php echo e($data['user_email']); ?></p>
        </div>
        <div class="bottom">
          <ul class="social-detail">
            <li><a target="_blank" href="<?php echo e($data['fb_url']); ?>" class="fab fa-facebook-f font-20 pointer p-l-5 p-r-5"></a></li>
            <li><a target="_blank" href="<?php echo e($data['insta_url']); ?>" class="fab fa-instagram font-20 pointer p-l-5 p-r-5"></a></li>
            <li><a target="_blank" href="<?php echo e($data['youtube_url']); ?>" class="fab fa-youtube font-20 pointer p-l-5 p-r-5"></a></li>
          </ul>
        </div>
      </div>

      <!-- About Me Box -->
      <div class="card">
      <div class="card-header">
        <h4 class="box-title">About Me</h4>

      </div>
      <!-- /.box-header -->
      <div class="card-body">
        <strong><i class="fa fa-book margin-r-5"></i> Bio</strong>

        <p class="text-muted">
        <?php echo e($data['bio']); ?>

        </p>

        <div class="card-body">
          <p>
            <strong> Profile Category</strong> : <?php echo e($profile_category_data['profile_category_name']); ?>

        </p>
        
        <p>
            <strong> Total Followers</strong> : <?php echo e($followers_count); ?>

        </p>
        <p>
            <strong> Total Following</strong> : <?php echo e($following_count); ?>

        </p>
        <p>
            <strong> Total Post</strong> : <?php echo e($total_videos); ?>

        </p>

      </div>

      </div>
      <!-- /.card-body -->
      </div>
      <!-- /.card -->
    </div>
    <div class="col-md-6">
       <div class="card">
         
        <div class="card-header">
        <h4 class="box-title">User Wallet</h4>
        </div>
      <!-- /.box-header -->
        <div class="row">
          <div class="col-md-6">
            <div class="card-body">
              <p>
                <strong> Total Received</strong> : <?php echo e($data['total_received']); ?>

              </p>
              <p>
                <strong> Total Send</strong> : <?php echo e($data['total_send']); ?>

              </p>
              <p>
                <strong> My Wallet</strong> : <?php echo e($data['my_wallet']); ?>

              </p>
              
              
            </div>
          </div>
          <div class="col-md-6">
            <div class="card-body">
              <p>
                <strong> Check In</strong> : <?php echo e($data['check_in']); ?>

              </p>
              <p>
                <strong> Upload Video</strong> : <?php echo e($data['upload_video']); ?>

              </p>
              <p>
                <strong> From Fans</strong> : <?php echo e($data['from_fans']); ?>

              </p>
              <p>
                <strong> Spend In App</strong> : <?php echo e($data['spen_in_app']); ?>

              </p>
              <p>
                <strong> Purchased</strong> : <?php echo e($data['purchased']); ?>

              </p>
            </div>
          </div>
        </div>
      </div>
      <div class="card">
        <div class="card-header">
        <h4 class="box-title">Send Notification</h4>
        </div>
      <!-- /.box-header -->
        <div class="col-md-12">
          <div class="col-md-12">
            <div class="card-body">
              <input type="hidden" name="user_id" id="user_id" value="<?php echo e($data['user_id']); ?>">
              <input type="text" placeholder="Please enter message" class="form-control" name="message" id="message">
            </div>
          </div>
          <div class="text-center mb-4">
            <input type="button" class="btn btn-primary btn-md" id="sendNotification" value="Send Notification">
          </div>
        </div>
      <!-- /.card-body -->
      </div>
    </div>
  </div>
</section>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('pageSpecificJs'); ?>

<script src="<?php echo e(asset('assets/bundles/jquery-ui/jquery-ui.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/bundles/izitoast/js/iziToast.min.js')); ?>"></script>

<script>

$(document).ready(function (){

  $(document).on('click', '#sendNotification', function (e) {

    var message = $("#message").val();
    var user_id = $("#user_id").val();

    if(message == "")
    {
        return false;
    }

    $.ajax({
      url: '<?php echo e(route("sendNotification")); ?>',
      data: {message:message,user_id:user_id},
      type: 'POST',
      dataType: "json",
      cache: false,
      success: function ( data ) {
          if(data.success == 1)
          {
            iziToast.success({
              title: 'Success!',
              message: 'Notification send successfully',
              position: 'topRight'
            });
              
          }
          else
          {
            iziToast.error({
              title: 'Error!',
              message: 'Notification send failed',
              position: 'topRight'
            });
          }
      }
  });   
});


</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin_layouts/main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\bubbletok-laravel\resources\views/admin/user/viewusers.blade.php ENDPATH**/ ?>