
<?php $__env->startSection('pageSpecificCss'); ?>
<style>

</style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<section class="section">
  <div class="row">

    <div class="col-lg-4 col-md-6 col-sm-6 col-xs-12">
        <div class="card">
            <div class="card-statistic-4 p-4">
                <i class="fa fa-user font-26 col-indigo float-right mt-2"></i>
                <div>
                    <h4 class="font-16 text-grayg">Today's Registration</h4>
                    <h2 class="font-18 mb-0 text-gray"><?php echo e($totalTodayUser); ?></h2>
                </div>
            </div>
        </div>
    </div>

    <div class="col-lg-4 col-md-6 col-sm-6 col-xs-12">
        <div class="card">
            <div class="card-statistic-4 p-4">
                <i class="fa fa-users font-26 col-indigo float-right mt-2"></i>
                <div>
                    <h4 class="font-16 text-grayg">Total Users</h4>
                    <h2 class="font-18 mb-0 text-gray"><?php echo e($totalUser); ?></h2>
                </div>
            </div>
        </div>
    </div>

    <div class="col-lg-4 col-md-6 col-sm-6 col-xs-12">
        <div class="card">
            <div class="card-statistic-4 p-4">
                <i class="fa fa-video font-26 col-indigo float-right mt-2"></i>
                <div>
                    <h4 class="font-16 text-grayg">Total Post</h4>
                    <h2 class="font-18 mb-0 text-gray"><?php echo e($totalPost); ?></h2>
                </div>
            </div>
        </div>
    </div>

    <div class="col-lg-4 col-md-6 col-sm-6 col-xs-12">
        <div class="card">
            <div class="card-statistic-4 p-4">
                <i class="fas fa-file-audio font-26 col-indigo float-right mt-2"></i>
                <div>
                    <h4 class="font-16 text-grayg">Total Music Category</h4>
                    <h2 class="font-18 mb-0 text-gray"><?php echo e($totalSoundCategory); ?></h2>
                </div>
            </div>
        </div>
    </div>

    <div class="col-lg-4 col-md-6 col-sm-6 col-xs-12">
        <div class="card">
            <div class="card-statistic-4 p-4">
                <i class="fa fa-music font-26 col-indigo float-right mt-2"></i>
                <div>
                    <h4 class="font-16 text-grayg">Total Music</h4>
                    <h2 class="font-18 mb-0 text-gray"><?php echo e($totalSound); ?></h2>
                </div>
            </div>
        </div>
    </div>

    <div class="col-lg-4 col-md-6 col-sm-6 col-xs-12">
        <div class="card">
            <div class="card-statistic-4 p-4">
                <i class="fa fa-transgender-alt font-26 col-indigo float-right mt-2"></i>
                <div>
                    <h4 class="font-16 text-grayg">Total Explore Tags</h4>
                    <h2 class="font-18 mb-0 text-gray"><?php echo e($totalHashTags); ?></h2>
                </div>
            </div>
        </div>
    </div>

    <div class="col-lg-4 col-md-6 col-sm-6 col-xs-12">
        <div class="card">
            <div class="card-statistic-4 p-4">
                <i class="fas fa-calendar-check font-26 col-indigo float-right mt-2"></i>
                <div>
                    <h4 class="font-16 text-grayg">Total Verification Request</h4>
                    <h2 class="font-18 mb-0 text-gray"><?php echo e($totalVerificationRequest); ?></h2>
                </div>
            </div>
        </div>
    </div>

    <div class="col-lg-4 col-md-6 col-sm-6 col-xs-12">
        <div class="card">
            <div class="card-statistic-4 p-4">
                <i class="fa fa-list-alt font-26 col-indigo float-right mt-2"></i>
                <div>
                    <h4 class="font-16 text-grayg">Total Reports</h4>
                    <h2 class="font-18 mb-0 text-gray"><?php echo e($totalReport); ?></h2>
                </div>
            </div>
        </div>
    </div>

    <div class="col-lg-4 col-md-6 col-sm-6 col-xs-12">
        <div class="card">
            <div class="card-statistic-4 p-4">
                <i class="fa fa-check-circle font-26 col-indigo float-right mt-2"></i>
                <div>
                    <h4 class="font-16 text-grayg">Total Verified Users</h4>
                    <h2 class="font-18 mb-0 text-gray"><?php echo e($totalVerifyUser); ?></h2>
                </div>
            </div>
        </div>
    </div>

    <div class="col-lg-4 col-md-6 col-sm-6 col-xs-12">
        <div class="card">
            <div class="card-statistic-4 p-4">
                <i class="fas fa-dollar-sign font-26 col-indigo float-right mt-2"></i>
                <div>
                    <h4 class="font-16 text-grayg">Coin Rate</h4>
                    <h2 class="font-18 mb-0 text-gray"><?php echo e($CoinRate['usd_rate']); ?></h2>
                </div>
            </div>
        </div>
    </div>

    <div class="col-lg-4 col-md-6 col-sm-6 col-xs-12">
        <div class="card">
            <div class="card-statistic-4 p-4">
                <i class="far fa-credit-card font-26 col-indigo float-right mt-2"></i>
                <div>
                    <h4 class="font-16 text-grayg">Coin Wallet</h4>
                    <h2 class="font-18 mb-0 text-gray"><?php echo e($MyWallet); ?></h2>
                </div>
            </div>
        </div>
    </div>

    <div class="col-lg-4 col-md-6 col-sm-6 col-xs-12">
        <div class="card">
            <div class="card-statistic-4 p-4">
                <i class="fas fa-share font-26 col-indigo float-right mt-2"></i>
                <div>
                    <h4 class="font-16 text-grayg">Total Redeem Request</h4>
                    <h2 class="font-18 mb-0 text-gray"><?php echo e($totalRedeemRequest); ?></h2>
                </div>
            </div>
        </div>
    </div>

  </div>

</section>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('pageSpecificJs'); ?>
<script src="<?php echo e(asset('assets/bundles/chartjs/chart.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/dist/js/custom.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin_layouts/main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/retrytech.site/public_html/bubbletok-laravel/resources/views/admin/dashboard.blade.php ENDPATH**/ ?>