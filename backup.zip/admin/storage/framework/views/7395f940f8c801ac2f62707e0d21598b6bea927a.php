
<?php $__env->startSection('pageSpecificCss'); ?>
<link href="<?php echo e(asset('assets/bundles/datatables/datatables.min.css')); ?>" rel="stylesheet">
<link href="<?php echo e(asset('assets/bundles/datatables/DataTables-1.10.16/css/dataTables.bootstrap4.min.css')); ?>" rel="stylesheet">

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<section class="section">

    <div class="row ">
      
        <div class="col-xl-3 col-lg-3 col-md-3 col-sm-3 col-xs-12">
            <div class="card">
                <div class="card-statistic-4">
                    <div class="align-items-center justify-content-between">
                        <div class="row ">
                            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 pr-0 ">
                                <div class="card-content text-center">
                                    <h3 class="font-20 total_course" style="color: dodgerblue;"> <?php echo e($total_course); ?> </h3>
                                    <span class="badge badge-success text-center">All</span>
                                </div>
                            </div>                            
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-xl-3 col-lg-3 col-md-3 col-sm-3 col-xs-12">
            <div class="card">
                <div class="card-statistic-4">
                    <div class="align-items-center justify-content-between">
                        <div class="row ">
                            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 pr-0 ">
                                <div class="card-content text-center">
                                    <h3 class="font-20 total_fetured_course" style="color: dodgerblue;"> <?php echo e($total_fetured_course); ?> </h3>
                                    <span class="badge badge-danger text-center">Featured</span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-xl-3 col-lg-3 col-md-3 col-sm-3 col-xs-12">
            <div class="card">
                <div class="card-statistic-4">
                    <div class="align-items-center justify-content-between">
                        <div class="row ">
                            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 pr-0 ">
                                <div class="card-content text-center">
                                    <h3 class="font-20 total_popular_course" style="color: dodgerblue;"> <?php echo e($total_popular_course); ?> </h3>
                                    <span class="badge badge-primary text-center">Popular</span>
                                </div>
                            </div>                            
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-xl-3 col-lg-3 col-md-3 col-sm-3 col-xs-12">
            <div class="card">
                <div class="card-statistic-4">
                    <div class="align-items-center justify-content-between">
                        <div class="row ">
                            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 pr-0 ">
                                <div class="card-content text-center">
                                    <h3 class="font-20 total_bestseller_course" style="color: dodgerblue;"> <?php echo e($total_bestseller_course); ?> </h3>
                                    <span class="badge badge-warning text-center">Best Selller</span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
    </div>
  <div class="section-body">
      <div class="row">
        <div class="col-12">
          <div class="card">
            <div class="card-header">
              <h4>Course List </h4>
            </div>

            <div class="card-body">
                <div class="pull-right">
                    <div class="buttons"> 
                    <a class="btn btn-primary text-light" href="<?php echo e(route('course/add')); ?>" >Add Course</a>
                    </div>
                </div>
              <div class="tab" role="tabpanel">
                <ul class="nav nav-pills border-b mb-0 p-3">
                    <li role="presentation" class="nav-item"><a class="nav-link pointer active" href="#Section1" aria-controls="home" role="tab" data-toggle="tab">All </a></li>
                    <li role="presentation" class="nav-item"><a class="nav-link pointer" href="#Section2" role="tab" data-toggle="tab">Feature </a></li>
                    <li role="presentation" class="nav-item"><a class="nav-link pointer" href="#Section3" role="tab" data-toggle="tab">Popular </a></li>
                    <li role="presentation" class="nav-item"><a class="nav-link pointer" href="#Section4" role="tab" data-toggle="tab">Best Seller </a></li>
                </ul>
              <div class="tab-content tabs" id="home">
							
              <div role="tabpanel" class="tab-pane active" id="Section1">
           
                <div class="card-body">	
                 
                  <div class="table-responsive">
                      <table class="table table-striped" id="course-listing">
                        <thead>
                          <tr>
                            <th>Title </th>
                            <th>Image</th>
                            <th>Author</th>
                            <th>Language</th>
                            <th>Duration</th>
                            <th>Price</th>
                            <th>Is Featured</th>
                            <th>Is Popular</th>
                            <th>Is Bestseller</th>
                            <th>Status</th>
                            <th>Action</th>
                          </tr>
                        </thead>
                        <tbody>

                        </tbody>
                      </table>
                  </div>
                </div>
              </div>

              <div role="tabpanel" class="tab-pane" id="Section2">
                <div class="card-body">	
                  <div class="table-responsive">
                    <table class="table table-striped" id="feature-course-listing" width="100%">
                      <thead>
                        <tr>
                            <th>Title </th>
                            <th>Image</th>
                            <th>Author</th>
                            <th>Language</th>
                            <th>Duration</th>
                            <th>Price</th>
                            <th>Is Featured</th>
                            <th>Status</th>
                            <th>Action</th>
                        </tr>
                      </thead>
                      <tbody>

                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
              
              <div role="tabpanel" class="tab-pane" id="Section3">
                <div class="card-body">	
                  <div class="table-responsive">
                    <table class="table table-striped" id="popular-course-listing" width="100%">
                      <thead>
                        <tr>
                            <th>Title </th>
                            <th>Image</th>
                            <th>Author</th>
                            <th>Language</th>
                            <th>Duration</th>
                            <th>Price</th>
                            <th>Is Popular</th>
                            <th>Status</th>
                            <th>Action</th>
                        </tr>
                      </thead>
                      <tbody>

                      </tbody>
                    </table>
                  </div>
                </div>
              </div>

              <div role="tabpanel" class="tab-pane" id="Section4">
                <div class="card-body">	
                  <div class="table-responsive">
                      <table class="table table-striped" id="bestseller-course-listing">
                        <thead>
                          <tr>
                            <th>Title </th>
                            <th>Image</th>
                            <th>Author</th>
                            <th>Language</th>
                            <th>Duration</th>
                            <th>Price</th>
                            <th>Is Bestseller</th>
                            <th>Status</th>
                            <th>Action</th>
                          </tr>
                        </thead>
                        <tbody>

                        </tbody>
                      </table>
                  </div>
                </div>
              </div>

          </div>

        </div>
      </div>
    </div>
  </div>
</section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('pageSpecificJs'); ?>

<script src="<?php echo e(asset('assets/bundles/datatables/datatables.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/bundles/datatables/DataTables-1.10.16/js/dataTables.bootstrap4.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/bundles/jquery-ui/jquery-ui.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/page/datatables.js')); ?>"></script>
<script src="<?php echo e(asset('assets/bundles/izitoast/js/iziToast.min.js')); ?>"></script>

<script>
$(document).ready(function (){
  var dataTable = $('#course-listing').dataTable({
    'processing': true,
    'serverSide': true,
    'serverMethod': 'post',
    "order": [[ 0, "desc" ]],
    'columnDefs': [ {
          'targets': [9,10], /* column index */
          'orderable': false, /* true or false */
        }],
    'ajax': {
        'url':'<?php echo e(route("showCourseList")); ?>',
        'data': function(data){
          data.flag = 0;
        }
    }
  });

  var dataTable1 = $('#feature-course-listing').dataTable({
    'processing': true,
    'serverSide': true,
    'serverMethod': 'post',
    "order": [[ 0, "desc" ]],
    'columnDefs': [ {
          'targets': [7,8], /* column index */
          'orderable': false, /* true or false */
        }],
    'ajax': {
        'url':'<?php echo e(route("showCourseList")); ?>',
        'data': function(data){
          data.flag = 1
        }
    }
  });

  var dataTable2 = $('#popular-course-listing').dataTable({
    'processing': true,
    'serverSide': true,
    'serverMethod': 'post',
    "order": [[ 0, "desc" ]],
    'columnDefs': [ {
          'targets': [7,8], /* column index */
          'orderable': false, /* true or false */
        }],
    'ajax': {
        'url':'<?php echo e(route("showCourseList")); ?>',
        'data': function(data){
            // Read values
            data.flag = 2
        }
    }
  });

  var dataTable3 = $('#bestseller-course-listing').dataTable({
    'processing': true,
    'serverSide': true,
    'serverMethod': 'post',
    "order": [[ 0, "desc" ]],
    'columnDefs': [ {
          'targets': [7,8], /* column index */
          'orderable': false, /* true or false */
        }],
    'ajax': {
        'url':'<?php echo e(route("showCourseList")); ?>',
        'data': function(data){
            // Read values
            data.flag = 3;
        }
    }
  });

  $(document).on('click', '#changeFeatureStatus', function (e) {
      e.preventDefault();
      var course_id = $(this).attr('data-id');
      var status = $(this).attr('data-status');
      if(status == 1){
        status = 0;
      }else{
        status = 1;
      }
      var text = 'You will not be able to recover this data!';   
      var confirmButtonText = 'Yes, Change Status!';
      var btn = 'btn-danger';
      swal({
        title: "Are you sure?",
        text: text,
        type: "warning",
        showCancelButton: true,
        confirmButtonClass: btn,
        confirmButtonText: confirmButtonText,
        cancelButtonText: "No, cancel please!",
        closeOnConfirm: false,
        closeOnCancel: false
      },
      function(isConfirm){
          if (isConfirm){
            $('.loader').show();
            $.ajax({
                url: '<?php echo e(route("changeFeatureStatus")); ?>',
                type: 'POST',
                data: {"course_id":course_id,"status":status},
                dataType: "json",
                cache: false,
                success: function (data) {
                    $('.loader').hide();
                    $('#course-listing').DataTable().ajax.reload(null, false);
                    $('.total_course').text(data.total_course);
                    $('.total_fetured_course').text(data.total_fetured_course);
                    $('.total_bestseller_course').text(data.total_bestseller_course);
                    $('.total_popular_course').text(data.total_popular_course);
                    swal("Confirm!", "Your Course has been changed!", "success");
                },
                error: function (jqXHR, textStatus, errorThrown) {
                    alert(errorThrown);
                }
            });
          } else {
          swal("Cancelled", "Your imaginary file is safe :)", "error");
        }
      });
    });


    $(document).on('click', '#changePopularStatus', function (e) {
      e.preventDefault();
      var course_id = $(this).attr('data-id');
      var status = $(this).attr('data-status');
      if(status == 1){
        status = 0;
      }else{
        status = 1;
      }
      var text = 'You will not be able to recover this data!';   
      var confirmButtonText = 'Yes, Change Status!';
      var btn = 'btn-danger';
      swal({
        title: "Are you sure?",
        text: text,
        type: "warning",
        showCancelButton: true,
        confirmButtonClass: btn,
        confirmButtonText: confirmButtonText,
        cancelButtonText: "No, cancel please!",
        closeOnConfirm: false,
        closeOnCancel: false
      },
      function(isConfirm){
          if (isConfirm){
            $('.loader').show();
            $.ajax({
                url: '<?php echo e(route("changePopularStatus")); ?>',
                type: 'POST',
                data: {"course_id":course_id,"status":status},
                dataType: "json",
                cache: false,
                success: function (data) {
                    $('.loader').hide();
                    $('#course-listing').DataTable().ajax.reload(null, false);
                    $('.total_course').text(data.total_course);
                    $('.total_fetured_course').text(data.total_fetured_course);
                    $('.total_bestseller_course').text(data.total_bestseller_course);
                    $('.total_popular_course').text(data.total_popular_course);
                    swal("Confirm!", "Your Course has been changed!", "success");
                },
                error: function (jqXHR, textStatus, errorThrown) {
                    alert(errorThrown);
                }
            });
          } else {
          swal("Cancelled", "Your imaginary file is safe :)", "error");
        }
      });
    });


    $(document).on('click', '#changeBestsellerStatus', function (e) {
      e.preventDefault();
      var course_id = $(this).attr('data-id');
      var status = $(this).attr('data-status');
      if(status == 1){
        status = 0;
      }else{
        status = 1;
      }
      var text = 'You will not be able to recover this data!';   
      var confirmButtonText = 'Yes, Change Status!';
      var btn = 'btn-danger';
      swal({
        title: "Are you sure?",
        text: text,
        type: "warning",
        showCancelButton: true,
        confirmButtonClass: btn,
        confirmButtonText: confirmButtonText,
        cancelButtonText: "No, cancel please!",
        closeOnConfirm: false,
        closeOnCancel: false
      },
      function(isConfirm){
          if (isConfirm){
            $('.loader').show();
            $.ajax({
                url: '<?php echo e(route("changeBestsellerStatus")); ?>',
                type: 'POST',
                data: {"course_id":course_id,"status":status},
                dataType: "json",
                cache: false,
                success: function (data) {
                    $('.loader').hide();
                    $('#course-listing').DataTable().ajax.reload(null, false);
                    $('.total_course').text(data.total_course);
                    $('.total_fetured_course').text(data.total_fetured_course);
                    $('.total_bestseller_course').text(data.total_bestseller_course);
                    $('.total_popular_course').text(data.total_popular_course);
                    swal("Confirm!", "Your Course has been changed!", "success");
                },
                error: function (jqXHR, textStatus, errorThrown) {
                    alert(errorThrown);
                }
            });
          } else {
          swal("Cancelled", "Your imaginary file is safe :)", "error");
        }
      });
    });

  $(document).on('click', '#changeCourseStatus', function (e) {
      e.preventDefault();
      var course_id = $(this).attr('data-id');
      var status = $(this).attr('data-status');
      if(status == 1){
        status = 0;
      }else{
        status = 1;
      }
      var text = 'You will not be able to recover this data!';   
      var confirmButtonText = 'Yes, Change Status!';
      var btn = 'btn-danger';
      swal({
        title: "Are you sure?",
        text: text,
        type: "warning",
        showCancelButton: true,
        confirmButtonClass: btn,
        confirmButtonText: confirmButtonText,
        cancelButtonText: "No, cancel please!",
        closeOnConfirm: false,
        closeOnCancel: false
      },
      function(isConfirm){
          if (isConfirm){
            $('.loader').show();
            $.ajax({
                url: '<?php echo e(route("changeCourseStatus")); ?>',
                type: 'POST',
                data: {"course_id":course_id,"status":status},
                dataType: "json",
                cache: false,
                success: function (data) {
                    $('.loader').hide();
                    $('#course-listing').DataTable().ajax.reload(null, false);
                    $('.total_course').text(data.total_course);
                    $('.total_fetured_course').text(data.total_fetured_course);
                    $('.total_bestseller_course').text(data.total_bestseller_course);
                    $('.total_popular_course').text(data.total_popular_course);
                    swal("Confirm!", "Your Course has been changed!", "success");
                },
                error: function (jqXHR, textStatus, errorThrown) {
                    alert(errorThrown);
                }
            });
          } else {
          swal("Cancelled", "Your imaginary file is safe :)", "error");
        }
      });
    });

    $(document).on('click', '.DeleteCourse', function (e) {
        e.preventDefault();
        var course_id = $(this).attr('data-id');
        var text = 'You will not be able to recover Course data!';   
        var confirmButtonText = 'Yes, Delete it!';
        var btn = 'btn-danger';
        swal({
        title: "Are you sure?",
        text: text,
        type: "warning",
        showCancelButton: true,
        confirmButtonClass: btn,
        confirmButtonText: confirmButtonText,
        cancelButtonText: "No, cancel please!",
        closeOnConfirm: false,
        closeOnCancel: false
        },
        function(isConfirm){
            if (isConfirm){
                $('.loader').show();
                $.ajax({
                    url: '<?php echo e(route("deleteCourse")); ?>',
                    type: 'POST',
                    data: {"course_id":course_id},
                    dataType: "json",
                    cache: false,
                    success: function (data) {
                        $('.loader').hide();
                        $('#course-listing').DataTable().ajax.reload(null, false);
                        $('.total_course').text(data.total_course);
                        $('.total_fetured_course').text(data.total_fetured_course);
                        $('.total_bestseller_course').text(data.total_bestseller_course);
                        $('.total_popular_course').text(data.total_popular_course);
                        if (data.success == 1) {
                        swal("Confirm!", "Course has been deleted!", "success");
                        } else {
                        swal("Confirm!", "Course has not been deleted!", "error");
                        }
                    },
                    error: function (jqXHR, textStatus, errorThrown) {
                        alert(errorThrown);
                    }
                });
            } else {
            swal("Cancelled", "Your imaginary file is safe :)", "error");
            }
        });
    });
});
</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin_layouts/main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\learny\resources\views/admin/course/course_list.blade.php ENDPATH**/ ?>