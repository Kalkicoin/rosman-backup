
<?php $__env->startSection('pageSpecificCss'); ?>
<style>

</style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<section class="section">
  <div class="row ">

    <div class="col-lg-3 col-md-6 col-sm-6 col-12">
      <div class="card card-statistic-1">
        <div class="card-icon l-bg-purple">
          <i class="fas fa-users"></i>
        </div>
        <div class="card-wrap">
          <div class="padding-20">
            <div class="text-right">
              <h3 class="font-light mb-0">
                <i class="ti-arrow-up text-success"></i>  <h2><?php echo e($totalUser); ?></h2>
              </h3>
             <h5 class="font-15"> Users</h5>
            </div>
          </div>
        </div>
      </div>
    </div>

    <div class="col-lg-3 col-md-6 col-sm-6 col-12">
      <div class="card card-statistic-1">
        <div class="card-icon l-bg-orange">
          <i class="fas fa-hiking"></i>
        </div>
        <div class="card-wrap">
          <div class="padding-20">
            <div class="text-right">
              <h3 class="font-light mb-0">
                <i class="ti-arrow-up text-success"></i>  <h2><?php echo e($totalActiveUser); ?></h2>
              </h3>
             <h5 class="font-15">Active Users</h5>
            </div>
          </div>
        </div>
      </div>
    </div>

    <div class="col-lg-3 col-md-6 col-sm-6 col-12">
      <div class="card card-statistic-1">
        <div class="card-icon l-bg-green">
          <i class="fas fa-crown"></i>
        </div>
        <div class="card-wrap">
          <div class="padding-20">
            <div class="text-right">
              <h3 class="font-light mb-0">
                <i class="ti-arrow-up text-success"></i>  <h2><?php echo e($totalPremiumUser); ?></h2>
              </h3>
             <h5 class="font-15">Premium Users</h5>
            </div>
          </div>
        </div>
      </div>
    </div>

    <div class="col-lg-3 col-md-6 col-sm-6 col-12">
      <div class="card card-statistic-1">
        <div class="card-icon bg-cyan">
          <i class="fas fa-calendar-alt"></i>
        </div>
        <div class="card-wrap">
          <div class="padding-20">
            <div class="text-right">
              <h3 class="font-light mb-0">
                <i class="ti-arrow-up text-success"></i>  <h2><?php echo e($totalTodayUser); ?></h2>
              </h3>
             <h5 class="font-15">Today's Users</h5>
            </div>
          </div>
        </div>
      </div>
    </div>
  
    <div class="col-lg-3 col-md-6 col-sm-6 col-12">
      <div class="card card-statistic-1">
        <div class="card-icon bg-info">
          <i class="fas fa-book-open"></i>
        </div>
        <div class="card-wrap">
          <div class="padding-20">
            <div class="text-right">
              <h3 class="font-light mb-0">
                <i class="ti-arrow-up text-success"></i>  <h2><?php echo e($totalCourseData); ?></h2>
              </h3>
             <h5 class="font-15">Total Course</h5>
            </div>
          </div>
        </div>
      </div>
    </div>

    <div class="col-lg-3 col-md-6 col-sm-6 col-12">
      <div class="card card-statistic-1">
        <div class="card-icon bg-danger">
          <i class="fas fa-bookmark"></i>
        </div>
        <div class="card-wrap">
          <div class="padding-20">
            <div class="text-right">
              <h3 class="font-light mb-0">
                <i class="ti-arrow-up text-success"></i>  <h2><?php echo e($totalFeaturedData); ?></h2>
              </h3>
             <h5 class="font-15">Featured Course</h5>
            </div>
          </div>
        </div>
      </div>
    </div>
    
    
    <div class="col-lg-3 col-md-6 col-sm-6 col-12">
      <div class="card card-statistic-1">
        <div class="card-icon l-bg-cyan">
          <i class="fas fa-book-reader"></i>
        </div>
        <div class="card-wrap">
          <div class="padding-20">
            <div class="text-right">
              <h3 class="font-light mb-0">
                <i class="ti-arrow-up text-success"></i>  <h2><?php echo e($totalPopularData); ?></h2>
              </h3>
             <h5 class="font-15">Popular Course</h5>
            </div>
          </div>
        </div>
      </div>
    </div>

    <div class="col-lg-3 col-md-6 col-sm-6 col-12">
      <div class="card card-statistic-1">
        <div class="card-icon bg-success">
          <i class="fas fa-book"></i>
        </div>
        <div class="card-wrap">
          <div class="padding-20">
            <div class="text-right">
              <h3 class="font-light mb-0">
                <i class="ti-arrow-up text-success"></i>  <h2><?php echo e($totalBestSellerData); ?></h2>
              </h3>
             <h5 class="font-15">Bestsellers Course</h5>
            </div>
          </div>
        </div>
      </div>
    </div>

    <div class="col-lg-3 col-md-6 col-sm-6 col-12">
      <div class="card card-statistic-1">
        <div class="card-icon bg-danger">
          <i class="far fa-folder-open"></i>
        </div>
        <div class="card-wrap">
          <div class="padding-20">
            <div class="text-right">
              <h3 class="font-light mb-0">
                <i class="ti-arrow-up text-success"></i>  <h2><?php echo e($totalOpenSupport); ?></h2>
              </h3>
             <h5 class="font-15">Open Ticket</h5>
            </div>
          </div>
        </div>
      </div>
    </div>

    <div class="col-lg-3 col-md-6 col-sm-6 col-12">
      <div class="card card-statistic-1">
        <div class="card-icon l-bg-green">
          <i class="fas fa-ticket-alt"></i>
        </div>
        <div class="card-wrap">
          <div class="padding-20">
            <div class="text-right">
              <h3 class="font-light mb-0">
                <i class="ti-arrow-up text-success"></i>  <h2><?php echo e($totalCloseSupport); ?></h2>
              </h3>
             <h5 class="font-15">Resolved Ticket</h5>
            </div>
          </div>
        </div>
      </div>
    </div>

  </div>


</section>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('pageSpecificJs'); ?>
<script src="<?php echo e(asset('assets/bundles/chartjs/chart.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/dist/js/custom.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin_layouts/main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\learny-new\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>