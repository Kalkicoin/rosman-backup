
<?php $__env->startSection('pageSpecificCss'); ?>
<link href="<?php echo e(asset('assets/bundles/datatables/datatables.min.css')); ?>" rel="stylesheet">
<link href="<?php echo e(asset('assets/bundles/datatables/DataTables-1.10.16/css/dataTables.bootstrap4.min.css')); ?>" rel="stylesheet">
<link href="<?php echo e(asset('assets/bundles/summernote/summernote-bs4.css')); ?>" rel="stylesheet">
<link href="<?php echo e(asset('assets/bundles/izitoast/css/iziToast.min.css')); ?>" rel="stylesheet">

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<section class="section">
  <div class="section-body">
        <div class="row">
            <div class="col-12">
                <div class="card">
                    <div class="card-header">
                        <h4>Resource List (<span class="total_resource"><?php echo e($total_resource); ?></span>)</h4>
                    </div>
                   
                    <div class="card-body">	

                        <div class="pull-left form-row col-md-6 mb-4">
                          <label for="course_id">Select Course</label>
                          <select id="searchByCourseId" name="search_course_id" class="form-control form-control-danger">
                            <option value="">--Select Course--</option>
                            <?php $__currentLoopData = $courseData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($val->course_id); ?>"><?php echo e($val->title); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                          </select>
                        </div>

                        <div class="pull-right">
                            <div class="buttons"> 
                                <button class="btn btn-info text-light" data-toggle="modal" data-target="#resourceModal" data-whatever="@mdo">Add Resource</button>
                            </div>
                        </div>
                        <div class="table-responsive">
                            <table class="table table-striped" id="resource-listing">
                                <thead>
                                <tr>
                                    <th>Course</th>
                                    <th>Title</th>
                                    <th>Content</th>
                                    <th>Action</th>
                                </tr>
                                </thead>
                                <tbody>

                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<div class="modal fade" id="resourceModal" tabindex="-1" role="dialog" aria-labelledby="ModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="ModalLabel"> Add Resource </h5>
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
        <form id="addUpdateResource" method="post" enctype="multipart">
        <?php echo e(csrf_field()); ?>

          <div class="modal-body">
            <div class="form-group">
              <label for="course_id">Select Course</label>
              <select id="course_id" name="course_id" class="form-control form-control-danger">
                <option value="">--Select--</option>
                <?php $__currentLoopData = $courseData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($val->course_id); ?>"><?php echo e($val->title); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </select>
            </div>

            <div class="form-group">
              <label for="resource_title">Title</label>
              <input type="text" placeholder="Title" name="resource_title" id="resource_title" class="form-control form-control-danger">
            </div>

            <div class="form-group">
              <label for="content_type">Content type</label>
              <select id="content_type" name="content_type" class="form-control form-control-danger">
                <option value="1" selected>PDF</option>
                <option value="2">ZIP</option>
                <option value="3">URL</option>
              </select>
            </div>

            <div class="form-group content_media_div">
              <label for="content" class="content_label" >Upload PDF</label>
              <input type="file" class="form-control-file file-upload custom_image valid" id="content" name="content" aria-required="true" aria-invalid="false">
              <div class="progress progress" style="height: 25px;margin:10px 0px;">
                  <div class="progress-bar" width="">0%</div>
              </div>
              <div class="preview_media mt-4">
                
              </div>
            </div>
            <input type="hidden" name="hidden_preview_content" id="hidden_preview_content" value="">
            
            <div class="form-group content_text_div">
              <label for="content">URL</label>
              <input type="text" placeholder="Content" name="url_content" id="url_content" class="form-control form-control-danger">
            </div>
          </div>
          <div class="modal-footer">
              <input type="hidden" name="resource_id" id="resource_id" value="">
            <button type="submit" class="btn btn-success addResourcebtn">Save</button>
            <button type="button" class="btn btn-light" data-dismiss="modal">Close</button>
          </div>
        </form>
      </div>
    </div>
  </div>

  <div class="modal fade" id="resourceContentViewModal" tabindex="-1" role="dialog" aria-labelledby="resourceContentViewModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-lg" role="document">
    <div class="modal-content ">
      <div class="modal-header">
        <h5 class="modal-title" id="resourceContentViewModalLabel">Preview Content</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">×</span>
        </button>
      </div>
      <div class="modal-body">
        <div id="ContentPreview">

        </div>
      </div>
     
    </div>
  </div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('pageSpecificJs'); ?>

<script src="<?php echo e(asset('assets/bundles/datatables/datatables.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/bundles/datatables/DataTables-1.10.16/js/dataTables.bootstrap4.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/bundles/jquery-ui/jquery-ui.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/page/datatables.js')); ?>"></script>
<script src="<?php echo e(asset('assets/bundles/izitoast/js/iziToast.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/bundles/summernote/summernote-bs4.js')); ?>"></script>

<script>
$(document).ready(function (){
  var dataTable = $('#resource-listing').dataTable({
    'processing': true,
    'serverSide': true,
    'serverMethod': 'post',
    "order": [[ 0, "desc" ]],
    'columnDefs': [ {
          'targets': [3], /* column index */
          'orderable': false, /* true or false */
        }],
    'ajax': {
        'url':'<?php echo e(route("showResourceList")); ?>',
        'data': function(data){
          data.course_id = $('#searchByCourseId').val()
        }
    }
  });

  $(document).on('change', '#searchByCourseId', function (e) {
    $('#resource-listing').DataTable().ajax.reload(null, false);
  });

  
  $(document).on('change', '#content', function () {
    CheckFileExtention(this,'.preview_media');
  });

  var CheckFileExtention = function (input, cl) {
    var content_type = $('#content_type').val();
    console.log(content_type);
    if (input.files) {
        if(content_type == 1){
            var allowedExtensions = /(\.pdf)$/i;
        }else{
            var allowedExtensions =  /(\.zip|\.rar)$/i;
        }
        if (!allowedExtensions.exec(input.value)) {
            if(content_type == 1){
                var msg = 'Please upload PDF File only.';
            }else{
                var msg = 'Please upload ZIP File only.';
            }
            iziToast.error({
                title: 'Error!',
                message: msg,
                position: 'topRight'
            });
            input.value = '';
            return false;
        } else {
            $('.addResourcebtn').attr('disabled',true);
            var formdata = new FormData($("#addUpdateResource")[0]);
            $.ajax({
                xhr: function() {
                var xhr = new window.XMLHttpRequest();
                xhr.upload.addEventListener("progress", function(evt) {
                    if (evt.lengthComputable) {
                    var percentComplete = ((evt.loaded / evt.total) * 100);
                    percentComplete = percentComplete.toFixed(2);
                    $(".progress-bar").width(percentComplete + '%');
                    $(".progress-bar").html(percentComplete + '%');
                    }
                }, false);
                    return xhr;
                },
                type: 'POST',
                url: '<?php echo e(route("UpdateResourceMedia")); ?>',
                data: formdata,
                contentType: false,
                cache: false,
                processData: false,
                dataType: "json",
                beforeSend: function() {
                    $(".progress-bar").width('0%');
                    $(cl).html("");
                },
                error: function() {
                    $(cl).html('<p style="color:#EA4335;">File upload failed, please try again.</p>');
                },
                success: function(data) {
                    if (data.success == 1) {
                        $('.addResourcebtn').attr('disabled',false);
                        $('#hidden_preview_content').val(data.resource_content);
                        if(content_type == 1){
                          $(cl).html('<a href="'+data.default_path+data.resource_content+'" ><div class="box"> <div class="card1"> <div class="card__corner">  <div class="card__corner-triangle"></div> </div>  <i class="fas fa-file-pdf" style="font-size:48px;color:red"></i> </div> </div></a>');
                        }else{
                          $(cl).html('<a href="'+data.default_path+data.resource_content+'" ><div class="box"> <div class="card1"> <div class="card__corner">  <div class="card__corner-triangle"></div> </div>  <i class="fas fa-file-archive" style="font-size:48px;color:teal;"></i> </div> </div></a>');
                        }

                    } 
                }
            });
        }
    }
  };
  $('.content_text_div').hide();
  $(document).on('change', '#content_type', function (e) {
    var value = $(this).val();
    if(value == 1){
      $('.content_media_div').show();
      $('.content_text_div').hide();
      $('.content_label').text('Upload PDF');
    }else if(value == 2){
      $('.content_media_div').show();
      $('.content_text_div').hide();
      $('.content_label').text('Upload ZIP');
    }else{
      $('.content_media_div').hide();
      $('.content_text_div').show();
    }
  });

  $('#resourceModal').on('hidden.bs.modal', function(e) {
      $("#addUpdateResource")[0].reset();
      $('.modal-title').text('Add Resource');
      $('#resource_id').val("");
      $('.content_media_div').show();
      $('.content_text_div').hide();
      $('.content_label').text('Upload PDF');
      $('#content_type').val(1);
      $('.preview_media').html("");
      $(".progress-bar").width('0%');
      $(".progress-bar").html('0%');
      var validator = $("#addUpdateResource").validate();
      validator.resetForm();
  });

  $("#resource-listing").on("click", ".UpdateResource", function() {
      $('.loader').show();
      $('.modal-title').text('Edit Resource');
      $('#resource_id').val($(this).attr('data-id'));
      $('#course_id').val($(this).attr('data-course_id'));
      $('#resource_title').val($(this).attr('data-resource_title'));
      $('#content_type').val($(this).attr('data-content_type'));
      var content_type = $(this).attr('data-content_type');
      var default_path = $(this).attr('data-default_path');
      var resource_content = $(this).attr('data-resource_content');
      if(content_type == 1){
        $('.content_media_div').show();
        $('.content_text_div').hide();
        $('.content_label').text('Upload PDF');
        $('.preview_media').html('<a href="'+default_path+resource_content+'" ><div class="box"> <div class="card1"> <div class="card__corner">  <div class="card__corner-triangle"></div> </div>  <i class="fas fa-file-pdf" style="font-size:48px;color:red"></i> </div> </div></a>');
      }else if(content_type == 2){
        $('.content_media_div').show();
        $('.content_text_div').hide();
        $('.content_label').text('Upload ZIP');
        $('.preview_media').html('<a href="'+default_path+resource_content+'" ><div class="box"> <div class="card1"> <div class="card__corner">  <div class="card__corner-triangle"></div> </div>  <i class="fas fa-file-archive" style="font-size:48px;color:teal;"></i> </div> </div></a>');
      }else{
        $('.content_media_div').hide();
        $('.content_text_div').show();
        $('#url_content').val($(this).attr('data-content'));
      }
   
      $('.loader').hide();
  });

  $("#addUpdateResource").validate({
      rules: {
        resource_name:{
            required: true,
          },
          resource_position:{
            required: true,
          },
          about_resource:{
            required: true,
          }, 
      },
      messages: {
        resource_name: {
            required: "Please Enter Resource Name",
        },
        resource_position: {
            required: "Please Enter Resource Position",
        },
        about_resource: {
            required: "Please Enter About Resource",
        },
      }
  });

  $(document).on('submit', '#addUpdateResource', function (e) {
    e.preventDefault();
    
    var formdata = new FormData($("#addUpdateResource")[0]);
    $('.loader').show();
    $.ajax({
        url: '<?php echo e(route("addUpdateResource")); ?>',
        type: 'POST',
        data: formdata,
        dataType: "json",
        contentType: false,
        cache: false,
        processData: false,
        success: function (data) {
            $('.loader').hide();
            $('#resourceModal').modal('hide');
            if (data.success == 1) {

              $('#resource-listing').DataTable().ajax.reload(null, false);
              $('.total_resource').text(data.total_resource);
              iziToast.success({
                title: 'Success!',
                message: data.message,
                position: 'topRight'
              });
            } else {
              iziToast.error({
                title: 'Error!',
                message: data.message,
                position: 'topRight'
              });
            }
        },
        error: function (jqXHR, textStatus, errorThrown) {
            alert(errorThrown);
        }
    });
  });

  $(document).on('click', '.DeleteResource', function (e) {
    e.preventDefault();
    var resource_id = $(this).attr('data-id');
    var text = 'You will not be able to recover Resource data!';   
    var confirmButtonText = 'Yes, Delete it!';
    var btn = 'btn-danger';
    swal({
      title: "Are you sure?",
      text: text,
      type: "warning",
      showCancelButton: true,
      confirmButtonClass: btn,
      confirmButtonText: confirmButtonText,
      cancelButtonText: "No, cancel please!",
      closeOnConfirm: false,
      closeOnCancel: false
    },
    function(isConfirm){
        if (isConfirm){
            $('.loader').show();
            $.ajax({
                url: '<?php echo e(route("deleteResource")); ?>',
                type: 'POST',
                data: {"resource_id":resource_id},
                dataType: "json",
                cache: false,
                success: function (data) {
                    $('.loader').hide();
                    $('#resource-listing').DataTable().ajax.reload(null, false);
                    $('.total_resource').text(data.total_resource);
                    if (data.success == 1) {
                      swal("Confirm!", "Resource has been deleted!", "success");
                    } else {
                      swal("Confirm!", "Resource has not been deleted!", "error");
                    }
                },
                error: function (jqXHR, textStatus, errorThrown) {
                    alert(errorThrown);
                }
            });
          } else {
          swal("Cancelled", "Your imaginary file is safe :)", "error");
        }
      });
  });

});
</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin_layouts/main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\learny\resources\views/admin/resource/resource_list.blade.php ENDPATH**/ ?>