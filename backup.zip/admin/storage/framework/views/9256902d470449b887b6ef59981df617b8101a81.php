<div class="main-sidebar sidebar-style-2">
        <aside id="sidebar-wrapper">
          <div class="sidebar-brand">
            <a href="<?php echo e(url('/dashboard')); ?>"> <img alt="image" src="<?php echo e(asset('assets/dist/img/logo.png')); ?>" class="header-logo"> <span class="logo-name">Learny</span>
            </a>
            </a>
          </div>
          <ul class="sidebar-menu">
            <li class="menu-header">Main</li>
            <li class="dropdown <?php echo e(active_class(['dashboard'])); ?>">
              <a href="<?php echo e(url('/dashboard')); ?>" class="nav-link"><i data-feather="monitor"></i><span>Dashboard</span></a>
            </li>
            <li class="dropdown <?php if(request()->is('user/*')): ?><?php echo e('active'); ?><?php endif; ?> ">
              <a href="<?php echo e(url('/user/list')); ?>" class="nav-link"><i data-feather="users"></i><span>Users</span></a>
            </li>
            <li class="dropdown <?php echo e(active_class(['language/list'])); ?>">
              <a href="<?php echo e(url('/language/list')); ?>" class="nav-link"><i data-feather="list"></i><span>language</span></a>
            </li>
            <li class="dropdown <?php echo e(active_class(['author/list'])); ?>">
              <a href="<?php echo e(url('/author/list')); ?>" class="nav-link"><i data-feather="users"></i><span>Author</span></a>
            </li>
            <li class="dropdown <?php echo e(active_class(['feed/list'])); ?>">
              <a href="<?php echo e(url('/feed/list')); ?>" class="nav-link"><i data-feather="list"></i><span>Feed</span></a>
            </li>
            <li class="dropdown <?php if(request()->is('course/*')): ?><?php echo e('active'); ?><?php endif; ?>">
              <a href="<?php echo e(url('/course/list')); ?>" class="nav-link"><i data-feather="book-open"></i><span>Course</span></a>
            </li>
            <li class="dropdown <?php echo e(active_class(['section/list'])); ?>">
              <a href="<?php echo e(url('/section/list')); ?>" class="nav-link"><i data-feather="server"></i><span>Section</span></a>
            </li>
            
            <li class="dropdown <?php if(request()->is('lecture/*')): ?><?php echo e('active'); ?><?php endif; ?>">
              <a href="<?php echo e(url('/lecture/list')); ?>" class="nav-link"><i data-feather="wind"></i><span>Lecture</span></a>
            </li>
            
            <li class="dropdown <?php echo e(active_class(['announcements/list'])); ?>">
              <a href="<?php echo e(url('/announcements/list')); ?>" class="nav-link"><i data-feather="mic"></i><span>Announcements</span></a>
            </li>

            <li class="dropdown <?php echo e(active_class(['resources/list'])); ?>">
              <a href="<?php echo e(url('/resources/list')); ?>" class="nav-link"><i data-feather="anchor"></i><span>Resources</span></a>
            </li>

            <li class="dropdown <?php echo e(active_class(['notification/list'])); ?>">
              <a href="<?php echo e(url('/notification/list')); ?>" class="nav-link"><i data-feather="bell"></i><span>Notification</span></a>
            </li>

            <li class="dropdown <?php echo e(active_class(['support/list'])); ?>">
              <a href="<?php echo e(url('/support/list')); ?>" class="nav-link"><i data-feather="help-circle"></i><span>Support</span></a>
            </li>

            <li class="dropdown <?php echo e(active_class(['purchasehistory/list'])); ?>">
              <a href="<?php echo e(url('/purchasehistory/list')); ?>" class="nav-link"><i data-feather="credit-card"></i><span>Purchase List</span></a>
            </li>

          </ul>
        </aside>
      </div><?php /**PATH C:\xampp\htdocs\learny\resources\views/admin_layouts/sidebar.blade.php ENDPATH**/ ?>