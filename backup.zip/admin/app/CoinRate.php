<?php

namespace App;

use Illuminate\Foundation\Auth\User as Authenticatable;
use Laravel\Passport\HasApiTokens;

class CoinRate extends Authenticatable
{
	use HasApiTokens;
	protected $table = 'tbl_coin_rate';
	public $primaryKey = 'coin_rate_id';
	public $timestamps = true;
	public $incrementing = false;
}
