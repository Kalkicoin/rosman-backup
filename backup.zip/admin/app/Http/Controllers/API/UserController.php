<?php

namespace App\Http\Controllers\API;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Auth;
use Illuminate\Validation\Rule;
use Laravel\Passport\Token;
use Validator;
use Hash;
use DB;
use File;
use Log;
use Storage;
use App\User;
use App\Admin;
use App\Post;
use App\Followers;
use App\ProfileCategory;
use App\VerificationRequest;
use App\Notification;
use App\BlockUser;

class UserController extends Controller
{

    public function Registration(Request $request)
    {
       
        try {
            $headers = $request->headers->all();
            
            $verify_request_base = Admin::verify_request_base($headers);

            if (isset($verify_request_base['status']) && $verify_request_base['status'] == 401) {
                return response()->json(['success_code' => 401, 'message' => "Unauthorized Access!"]);
                exit();
            }

            $rules = [
                'full_name' => 'required',
                'user_email' => 'required',
                'device_token' => 'required',
                'user_name' => 'required', //|unique:tbl_users
                'identity' => 'required',
                'login_type' => 'required',
                'platform' => 'required',
            ];
    
            $validator = Validator::make($request->all(), $rules);
    
            if ($validator->fails()) {
                $messages = $validator->errors()->all();
                $msg = $messages[0];
                return response()->json(['status' => 401, 'message' => $msg]);
            }
            
            $CheckUSer =  User::where('identity', $request->get('identity'))->first();
            
            if (empty($CheckUSer)) {

                $data['full_name'] = $request->get('full_name');
                $data['user_email'] = $request->get('user_email');
                $data['device_token'] = $request->get('device_token');
                $data['user_name'] = $request->get('user_name');
                $data['identity'] = $request->get('identity');
                $data['login_type'] = $request->get('login_type');
                $data['platform'] = $request->get('platform');
              
                $result = User::insert($data);

                if (!empty($result)) {
                    $user_id = DB::getPdo()->lastInsertId();
                    $User =  User::where('user_id', $user_id)->first();

                    $User['token'] = 'Bearer ' . $User->createToken('learny')->accessToken;
                    $User['followers_count'] = Followers::where('to_user_id',$user_id)->count();
                    $User['following_count'] = Followers::where('from_user_id',$user_id)->count();
                    $User['my_post_likes'] = Post::select('tbl_post.*')->leftjoin('tbl_likes as l','l.post_id','tbl_post.post_id')->where('tbl_post.user_id',$user_id)->count();
                    $profile_category_data = ProfileCategory::where('profile_category_id',$User->profile_category)->first();
                    $User['profile_category_name'] = !empty($profile_category_data) ? $profile_category_data['profile_category_name'] : "";
                    unset($User->timezone);
                    unset($User->created_at);
                    unset($User->updated_at);
    
                    return response()->json(['status' => 200, 'message' => "User Registered Successfully.", 'data' => $User]);
                } else {
                    return response()->json(['status' => 401, 'message' => "Error While User Registration"]);
                }

            } else {
                $identity = $request->get('identity');
                $data['full_name'] = $request->get('full_name');
                $data['user_email'] = $request->get('user_email');
                $data['device_token'] = $request->get('device_token');
                $data['user_name'] = $request->get('user_name');
                $data['identity'] = $request->get('identity');
                $data['login_type'] = $request->get('login_type');
                $data['platform'] = $request->get('platform');
              
                $user_id = $CheckUSer->user_id;
                $result =  User::where('identity', $identity)->update($data);

                $User =  User::where('user_id', $user_id)->first();
    
                $User['token'] = 'Bearer ' . $User->createToken('learny')->accessToken;
     
                $User['token'] = 'Bearer ' . $User->createToken('learny')->accessToken;
                $User['followers_count'] = Followers::where('to_user_id',$user_id)->count();
                $User['following_count'] = Followers::where('from_user_id',$user_id)->count();
                $User['my_post_likes'] = Post::select('tbl_post.*')->leftjoin('tbl_likes as l','l.post_id','tbl_post.post_id')->where('tbl_post.user_id',$user_id)->count();
                $profile_category_data = ProfileCategory::where('profile_category_id',$User->profile_category)->first();
                $User['profile_category_name'] = !empty($profile_category_data) ? $profile_category_data['profile_category_name'] : "";
                $User['user_mobile_no'] = $User->user_mobile_no ? $User->user_mobile_no : "";
                $User['user_profile'] = $User->user_profile ? $User->user_profile : "";
                $User['bio'] = $User->bio ? $User->bio : "";
                $User['profile_category'] = $User->profile_category ? $User->profile_category : "";
                $User['fb_url'] = $User->fb_url ? $User->fb_url : "";
                $User['insta_url'] = $User->insta_url ? $User->insta_url : "";
                $User['youtube_url'] = $User->youtube_url ? $User->youtube_url : "";

                unset($User->timezone);
                unset($User->created_at);
                unset($User->updated_at);

                return response()->json(['status' => 200, 'message' => "User registered successfully.", 'data' => $User]);
            }
     
            
        } catch (\Exception $e) {
            Log::info($e->getMessage() . ', ' . basename((parse_url($e->getFile()))['path']) . '_line: ' . $e->getLine());
            return response()->json(['status' => 401, 'message' => "Something went wrong. Please try again."]);
        }
    }

    public function Logout()
    {
        try {

            if (Auth::check()) {
                $user = Auth::user();
                $accessToken = Auth::user()->token();
                if (isset($user->user_id)) {
                    DB::table('oauth_access_tokens')->where('id', $accessToken->id)->delete();
                    $data['device_token'] = "";
                    $data['platform'] = 0;
                    $result =  User::where('user_id', $user->user_id)->update($data);
                    return response()->json(['success_code' => 200, 'response_code' => 1, 'response_message' => "User logout successfully."]);
                } else {
                    return response()->json(['success_code' => 401, 'response_code' => 0, 'response_message' => "User Id is required"]);
                }
               
            } else {
                return response()->json(['success_code' => 401, 'response_code' => 0, 'response_message' => "User Id is required"]);
            }
        } catch (\Exception $e) {
            Log::info($e->getMessage() . ', ' . basename((parse_url($e->getFile()))['path']) . '_line: ' . $e->getLine());
            return response()->json(['success_code' => 401, 'response_code' => 0, 'response_message' => "Something went wrong. Please try again."]);
        }
    }

    public function verifyRequest(Request $request)
    {
        try {
            $user_id = $request->user()->user_id;

            if (empty($user_id)) {
                $msg = "user id is required";
                return response()->json(['success_code' => 401, 'response_code' => 0, 'response_message' => $msg]);
            }


            $headers = $request->headers->all();
                
            $verify_request_base = Admin::verify_request_base($headers);

            if (isset($verify_request_base['status']) && $verify_request_base['status'] == 401) {
                return response()->json(['success_code' => 401, 'message' => "Unauthorized Access!"]);
                exit();
            }

            $rules = [
                'id_number' => 'required',
            ];
    
            $validator = Validator::make($request->all(), $rules);
    
            if ($validator->fails()) {
                $messages = $validator->errors()->all();
                $msg = $messages[0];
                return response()->json(['status' => 401, 'message' => $msg]);
            }
                       
            $User =  User::where('user_id', $user_id)->first();

            $count_approve = VerificationRequest::where('user_id', $user_id)->where('status', 1)->count(); 

            if($count_approve >= 1)
            {
                return response()->json(['status' => 200, 'message' => "Verification request already aproved."]);
            }
        
            $count_pending = VerificationRequest::where('user_id', $user_id)->where('status', 0)->count(); 

            if($count_pending == 1)
            {
                return response()->json(['status' => 200, 'message' => "Your Verification request pending."]);
            }

            $id_number = $request->get('id_number') ? $request->get('id_number') : '';
            $name = $request->get('name') ? $request->get('name') : '';
            $address = $request->get('address') ? $request->get('address') : '';
            $photo_id_image = "";

            $s3 = Storage::disk('s3');
            if ($request->hasfile('photo_id_image')) {
                $file = $request->file('photo_id_image');
                $namewithextension = $file->getClientOriginalName();
                $filename = explode('.', $namewithextension)[0];
                $imageFileName= 'photo_id_image_' . rand(111,999) . '.' . $file->getClientOriginalExtension(); 
                $destinationPath = env('DEFAULT_IMAGE_PATH');
                // File::makeDirectory($destinationPath, $mode = 0777, true, true);
                $filePath = $destinationPath . $imageFileName;
                if ($s3->put($filePath, file_get_contents($file), 'public') ){
                    $photo_id_image = $imageFileName;
                }            
            }

            $photo_with_id_image = "";

            $s3 = Storage::disk('s3');
            if ($request->hasfile('photo_with_id_image')) {
                $file = $request->file('photo_with_id_image');
                $namewithextension = $file->getClientOriginalName();
                $filename = explode('.', $namewithextension)[0];
                $imageFileName= 'photo_with_id_image_' . rand(111,999) . '.' . $file->getClientOriginalExtension(); 
                $destinationPath = env('DEFAULT_IMAGE_PATH');
                $filePath = $destinationPath . $imageFileName;
                if ($s3->put($filePath, file_get_contents($file), 'public') ){
                    $photo_with_id_image = $imageFileName;
                }            
            }

            $data = array(
                'id_number'=>$id_number,
                'user_id'=>$user_id,
                'name'=>$name,
                'address'=>$address,
                'photo_id_image'=>$photo_id_image,
                'photo_with_id_image'=>$photo_with_id_image,
            );

            $result = VerificationRequest::insert($data);
            $data1['is_verify'] = 2;
            User::where('user_id', $user_id)->update($data1);
            if (!empty($result)) 
            {
                return response()->json(['status' => 200, 'message' => "Verification request successfully send."]);
            }
            else
            {
                return response()->json(['status' => 401, 'message' => "Verification request send failed."]);
            }

        } catch (\Exception $e) {
            Log::info($e->getMessage() . ', ' . basename((parse_url($e->getFile()))['path']) . '_line: ' . $e->getLine());
            return response()->json(['status' => 401, 'message' => "Something went wrong. Please try again."]);
        }
    }

    public function checkUsername(Request $request)
    {
        try {
            $user_id = $request->user()->user_id;

            if (empty($user_id)) {
                $msg = "user id is required";
                return response()->json(['success_code' => 401, 'response_code' => 0, 'response_message' => $msg]);
            }

            $headers = $request->headers->all();
                
            $verify_request_base = Admin::verify_request_base($headers);

            if (isset($verify_request_base['status']) && $verify_request_base['status'] == 401) {
                return response()->json(['success_code' => 401, 'message' => "Unauthorized Access!"]);
                exit();
            }

            $rules = [
                'user_name' => 'required',
            ];
    
            $validator = Validator::make($request->all(), $rules);
    
            if ($validator->fails()) {
                $messages = $validator->errors()->all();
                $msg = $messages[0];
                return response()->json(['status' => 401, 'message' => $msg]);
            }
                       
            $user_name = $request->get('user_name');
            $result =  User::where('user_name', $user_name)->first();

            if (empty($result)) 
            {
                return response()->json(['status' => 200, 'message' => "Username generet successfully"]);
            }
            else
            {
                return response()->json(['status' => 401, 'message' => "Username already exist"]);
            }

        } catch (\Exception $e) {
            Log::info($e->getMessage() . ', ' . basename((parse_url($e->getFile()))['path']) . '_line: ' . $e->getLine());
            return response()->json(['status' => 401, 'message' => "Something went wrong. Please try again."]);
        }
    }

    public function getProfile(Request $request)
    {
        try {
            // $user_id = $request->user()->user_id;

            // if (empty($user_id)) {
            //     $msg = "user id is required";
            //     return response()->json(['success_code' => 401, 'response_code' => 0, 'response_message' => $msg]);
            // }


            $headers = $request->headers->all();
                
            $verify_request_base = Admin::verify_request_base($headers);

            if (isset($verify_request_base['status']) && $verify_request_base['status'] == 401) {
                return response()->json(['success_code' => 401, 'message' => "Unauthorized Access!"]);
                exit();
            }
            $user_id = $request->get('user_id');
            $my_user_id = $request->get('my_user_id') ? $request->get('my_user_id') : '';
            
            $is_count = Followers::where('from_user_id',$my_user_id)->where('to_user_id',$user_id)->count();
            
            if($is_count > 0)
            {
                $is_count = 1;
            }
            else
            {
                $is_count = 0;
            }
            $is_block = BlockUser::where('from_user_id',$my_user_id)->where('block_user_id',$user_id)->count();

            if($is_block > 0)
            {
                $is_block = 1;
            }
            else
            {
                $is_block = 0;
            }
                       
            $User =  User::where('user_id', $user_id)->first();
            if (empty($User)) {
                return response()->json(['status' => 401, 'message' => "User Not Found"]);
            }
            $User['followers_count'] = Followers::where('to_user_id',$user_id)->count();
            $User['following_count'] = Followers::where('from_user_id',$user_id)->count();
            $User['my_post_likes'] = Post::select('tbl_post.*')->leftjoin('tbl_likes as l','l.post_id','tbl_post.post_id')->where('tbl_post.user_id',$user_id)->count();
            $profile_category_data = ProfileCategory::where('profile_category_id',$User->profile_category)->first();
            $User['profile_category_name'] = !empty($profile_category_data) ? $profile_category_data['profile_category_name'] : "";
            $User['is_following'] = $is_count;
            $User['block_or_not'] = $is_block;
            $User['user_profile'] = $User->user_profile ? $User->user_profile : "";
            $User['user_mobile_no'] = $User->user_mobile_no ? $User->user_mobile_no : "";
            $User['bio'] = $User->bio ? $User->bio : "";
            $User['profile_category'] = $User->profile_category ? $User->profile_category : "";
            $User['fb_url'] = $User->fb_url ? $User->fb_url : "";
            $User['insta_url'] = $User->insta_url ? $User->insta_url : "";
            $User['youtube_url'] = $User->youtube_url ? $User->youtube_url : "";
            
            unset($User->status);
            unset($User->freez_or_not);
            unset($User->timezone);
            unset($User->created_at);
            unset($User->updated_at);

            return response()->json(['status' => 200, 'message' => "User Profile Get successfully.", 'data' => $User]);
        
        } catch (\Exception $e) {
            Log::info($e->getMessage() . ', ' . basename((parse_url($e->getFile()))['path']) . '_line: ' . $e->getLine());
            return response()->json(['status' => 401, 'message' => "Something went wrong. Please try again."]);
        }
    }

    public function updateProfile(Request $request)
    {
        try {
            $user_id = $request->user()->user_id;

            if (empty($user_id)) {
                $msg = "user id is required";
                return response()->json(['success_code' => 401, 'response_code' => 0, 'response_message' => $msg]);
            }

            $headers = $request->headers->all();
                
            $verify_request_base = Admin::verify_request_base($headers);

            if (isset($verify_request_base['status']) && $verify_request_base['status'] == 401) {
                return response()->json(['success_code' => 401, 'message' => "Unauthorized Access!"]);
                exit();
            }
            
           
            $rules = [
                'full_name' => 'required',
                'user_name' => 'required',
            ];
    
            $validator = Validator::make($request->all(), $rules);
    
            if ($validator->fails()) {
                $messages = $validator->errors()->all();
                $msg = $messages[0];
                return response()->json(['status' => 401, 'message' => $msg]);
            }
            
            $CheckUSer =  User::where('user_id', $user_id)->first();
            if (empty($CheckUSer)) {
                return response()->json(['status' => 401, 'message' => "User Not Found"]);
            }
            $s3 = Storage::disk('s3');
            $imageFileName = "";
            if ($request->hasfile('user_profile')) {
                $file = $request->file('user_profile');
                $namewithextension = $file->getClientOriginalName();
                $filename = explode('.', $namewithextension)[0];
                $imageFileName= 'user_profile_' . rand(111,999) . '.' . $file->getClientOriginalExtension();  
                $destinationPath = env('DEFAULT_IMAGE_PATH');
                $filePath = $destinationPath . $imageFileName;
                if ($s3->put($filePath, file_get_contents($file), 'public') ){
                    $data['user_profile'] = $imageFileName;
                }    
            }

            if(!empty($request->get('full_name'))){
                $data['full_name'] = $request->get('full_name');
            }
            if(!empty($request->get('user_email'))){
                $data['user_email'] = $request->get('user_email');
            }
            if(!empty($request->get('user_name'))){
                $data['user_name'] = $request->get('user_name');
            }
            if(!empty($request->get('user_mobile_no'))){
                $data['user_mobile_no'] = $request->get('user_mobile_no');
            }
            if(!empty($request->get('profile_category'))){
                $data['profile_category'] = $request->get('profile_category');
            }
            if(!empty($request->get('bio'))){
                $data['bio'] = $request->get('bio');
            }
            if(!empty($request->get('fb_url'))){
                $data['fb_url'] = $request->get('fb_url');
            }
            if(!empty($request->get('insta_url'))){
                $data['insta_url'] = $request->get('insta_url');
            }
            if(!empty($request->get('youtube_url'))){
                $data['youtube_url'] = $request->get('youtube_url');
            }
           
            $result =  User::where('user_id', $user_id)->update($data);
            if (!empty($result)) {
                
                $User =  User::where('user_id', $user_id)->first();
                $User['followers_count'] = Followers::where('to_user_id',$user_id)->count();
                $User['following_count'] = Followers::where('from_user_id',$user_id)->count();
                $User['my_post_likes'] = Post::select('tbl_post.*')->leftjoin('tbl_likes as l','l.post_id','tbl_post.post_id')->where('tbl_post.user_id',$user_id)->count();
                $profile_category_data = ProfileCategory::where('profile_category_id',$User->profile_category)->first();
                $User['profile_category_name'] = !empty($profile_category_data) ? $profile_category_data['profile_category_name'] : "";

                $User['user_profile'] = $User->user_profile ? $User->user_profile : "";
                $User['user_mobile_no'] = $User->user_mobile_no ? $User->user_mobile_no : "";
                $User['bio'] = $User->bio ? $User->bio : "";
                $User['profile_category'] = $User->profile_category ? $User->profile_category : "";
                $User['fb_url'] = $User->fb_url ? $User->fb_url : "";
                $User['insta_url'] = $User->insta_url ? $User->insta_url : "";
                $User['youtube_url'] = $User->youtube_url ? $User->youtube_url : "";
                
                unset($User->timezone);
                unset($User->created_at);
                unset($User->updated_at);

                return response()->json(['status' => 200, 'message' => "User details update successfully", 'data' => $User]);

            } else {
                return response()->json(['status' => 401, 'message' => "Error While User Profile Update", 'data' => []]);
            }
        } catch (\Exception $e) {
            Log::info($e->getMessage() . ', ' . basename((parse_url($e->getFile()))['path']) . '_line: ' . $e->getLine());
            return response()->json(['status' => 401, 'message' => "Something went wrong. Please try again."]);
        }
    }

    public function getNotificationList(Request $request)
    {
        
		try{
            $user_id = $request->user()->user_id;
            if (empty($user_id)) {
                $msg = "user id is required";
                return response()->json(['success_code' => 401, 'response_code' => 0, 'response_message' => $msg]);
            }

            $headers = $request->headers->all();
            $verify_request_base = Admin::verify_request_base($headers);

            if (isset($verify_request_base['status']) && $verify_request_base['status'] == 401) {
                return response()->json(['success_code' => 401, 'message' => "Unauthorized Access!"]);
                exit();
            }

            $rules = [
                'start' => 'required',
            ];

            $validator = Validator::make($request->all(), $rules);

            if ($validator->fails()) {
                $messages = $validator->errors()->all();
                $msg = $messages[0];
                return response()->json(['status' => 401, 'message' => $msg]);
            }
            
            $limit = $request->get('limit') ? $request->get('limit') : 20;
            $start = $request->get('start') ? $request->get('start') : 0;

			$NotificationData  = Notification::where('received_user_id',$user_id)->offset($start)
            ->limit($limit)
            ->get();
            
            $Data = [];
            if (count($NotificationData) > 0) {
                $i=0;
                foreach($NotificationData as $key => $value){
                    $userData  = User::where('user_id', $value['sender_user_id'])->first();

                    $Data[$i]['full_name'] = $userData['full_name'] ? $userData['full_name'] : "";
                    $Data[$i]['user_name'] = $userData['user_name'] ? $userData['user_name'] : "";
                    $Data[$i]['user_profile'] = $userData['user_profile'] ? $userData['user_profile'] : "";
                    $Data[$i]['sender_user_id'] = $value['sender_user_id'];
                    $Data[$i]['received_user_id'] = $value['received_user_id'];
                    $Data[$i]['item_id'] = $value['item_id'] ? $value['item_id'] : 0;
                    $Data[$i]['notification_type'] = $value['notification_type'] ? $value['notification_type'] : 0;
                    $Data[$i]['message'] = $value['message'] ? $value['message'] : "";
                    $i++;
                }

                return response()->json(['status' => 200, 'message' => "Notification Data Get Successfully.", 'data' => $Data]);
            } else {
                return response()->json(['status' => 401, 'message' => "No Data Found."]);
            }
        } catch (\Exception $e) {
            Log::info($e->getMessage() . ', ' . basename((parse_url($e->getFile()))['path']) . '_line: ' . $e->getLine());
            return response()->json(['success_code' => 401, 'response_code' => 0, 'response_message' => "Something went wrong. Please try again."]);
        }
    }

    public function setNotificationSettings(Request $request)
    {
        
		try{
            $user_id = $request->user()->user_id;
            if (empty($user_id)) {
                $msg = "user id is required";
                return response()->json(['success_code' => 401, 'response_code' => 0, 'response_message' => $msg]);
            }

            $headers = $request->headers->all();
            $verify_request_base = Admin::verify_request_base($headers);

            if (isset($verify_request_base['status']) && $verify_request_base['status'] == 401) {
                return response()->json(['success_code' => 401, 'message' => "Unauthorized Access!"]);
                exit();
            }

            $rules = [
                'device_token' => 'required',
            ];

            $validator = Validator::make($request->all(), $rules);

            if ($validator->fails()) {
                $messages = $validator->errors()->all();
                $msg = $messages[0];
                return response()->json(['status' => 401, 'message' => $msg]);
            }
            
            $device_token = $request->get('device_token') ? $request->get('device_token') : "";
            $data['device_token'] = $device_token;
			$result  = User::where('user_id',$user_id)->update($data);
            
            if ($result) {
                return response()->json(['status' => 200, 'message' => "Setting Update Successfully"]);
            } else {
                return response()->json(['status' => 401, 'message' => "Error While Setting Update"]);
            }

        } catch (\Exception $e) {
            Log::info($e->getMessage() . ', ' . basename((parse_url($e->getFile()))['path']) . '_line: ' . $e->getLine());
            return response()->json(['success_code' => 401, 'response_code' => 0, 'response_message' => "Something went wrong. Please try again."]);
        }
    }

    public function getProfileCategoryList(Request $request)
	{

		try{

            $user_id = $request->user()->user_id;
            if (empty($user_id)) {
                $msg = "user id is required";
                return response()->json(['success_code' => 401, 'response_code' => 0, 'response_message' => $msg]);
            }

            $headers = $request->headers->all();
            $verify_request_base = Admin::verify_request_base($headers);
            if (isset($verify_request_base['status']) && $verify_request_base['status'] == 401) {
                return response()->json(['success_code' => 401, 'message' => "Unauthorized Access!"]);
                exit();
            }

			$ProfileCategoryData  = ProfileCategory::orderBy('profile_category_id','DESC')->get();
      
            if (count($ProfileCategoryData) > 0) {

				$data = [];
                $i=0;
                foreach($ProfileCategoryData as $value){
                    $data[$i]['profile_category_id'] = $value['profile_category_id'];
                    $data[$i]['profile_category_name'] = $value['profile_category_name'];
                    $data[$i]['profile_category_image'] = $value['profile_category_image'] ? $value['profile_category_image'] : "";
                    $i++;
                }

                return response()->json(['status' => 200, 'message' => "Profile Category Data Get Successfully.", 'data' => $data]);
            } else {
                return response()->json(['status' => 401, 'message' => "No Data Found."]);
            }
        } catch (\Exception $e) {
            Log::info($e->getMessage() . ', ' . basename((parse_url($e->getFile()))['path']) . '_line: ' . $e->getLine());
            return response()->json(['success_code' => 401, 'response_code' => 0, 'response_message' => "Something went wrong. Please try again."]);
        }
	}

    public function blockUser(Request $request)
    { 
        try{
            $from_user_id = $request->user()->user_id;

            if (empty($from_user_id)) {
                $msg = "user id is required";
                return response()->json(['success_code' => 401, 'response_code' => 0, 'response_message' => $msg]);
            }

            $headers = $request->headers->all();
            $verify_request_base = Admin::verify_request_base($headers);

            if (isset($verify_request_base['status']) && $verify_request_base['status'] == 401) {
                return response()->json(['success_code' => 401, 'message' => "Unauthorized Access!"]);
                exit();
            }

            $rules = [
                'user_id' => 'required',
            ];

            $validator = Validator::make($request->all(), $rules);

            if ($validator->fails()) {
                $messages = $validator->errors()->all();
                $msg = $messages[0];
                return response()->json(['status' => 401, 'message' => $msg]);
            }
            
            $block_user_id = $request->get('user_id');

            $countBlockUser = BlockUser::where('from_user_id',$from_user_id)->where('block_user_id',$block_user_id)->count();

            if ($countBlockUser > 0) {

                $delete = BlockUser::where('from_user_id',$from_user_id)->where('block_user_id',$block_user_id)->delete();
                return response()->json(['status' => 200, 'message' => "User Unblock successful"]);
            } else {

                $data = array('block_user_id'=>$block_user_id,'from_user_id'=>$from_user_id);
                $insert =  BlockUser::insert($data); 
                
                return response()->json(['status' => 200, 'message' => "User Block successful."]);
            }
        } catch (\Exception $e) {
            Log::info($e->getMessage() . ', ' . basename((parse_url($e->getFile()))['path']) . '_line: ' . $e->getLine());
            return response()->json(['success_code' => 401, 'response_code' => 0, 'response_message' => "Something went wrong. Please try again."]);
        } 
    }

}
