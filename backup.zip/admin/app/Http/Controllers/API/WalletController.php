<?php

namespace App\Http\Controllers\API;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Auth;
use Illuminate\Validation\Rule;
use Validator;
use File;
use Session;
use DB;
use Log;
use App\Admin;
use App\Common;
use App\User;
use App\Post;
use App\CoinRate;
use App\CoinPlan;
use App\RewardingAction;
use App\Notification;
use App\RedeemRequest;

class WalletController extends Controller
{

	public function getCoinRateList(Request $request)
	{

		try{
         
            $headers = $request->headers->all();
                
            $verify_request_base = Admin::verify_request_base($headers);

            if (isset($verify_request_base['status']) && $verify_request_base['status'] == 401) {
                return response()->json(['success_code' => 401, 'message' => "Unauthorized Access!"]);
                exit();
            }

            $user_id = $request->user()->user_id;
	
            $CoinRateData =  CoinRate::where('coin_rate_id',1)->first();
		
            if (!empty($CoinRateData)) {
                return response()->json(['status' => 200, 'message' => "Coin Rate Data Get Successfully.", 'data' => $CoinRateData]);
            } else {
                return response()->json(['status' => 401, 'message' => "No Data Found.",'data'=>$CoinRateData]);
            }
        } catch (\Exception $e) {
            Log::info($e->getMessage() . ', ' . basename((parse_url($e->getFile()))['path']) . '_line: ' . $e->getLine());
            return response()->json(['success_code' => 401, 'response_code' => 0, 'response_message' => "Something went wrong. Please try again."]);
        }
	}

    public function getRewardingActionList(Request $request)
	{

		try{
         
            $headers = $request->headers->all();
                
            $verify_request_base = Admin::verify_request_base($headers);

            if (isset($verify_request_base['status']) && $verify_request_base['status'] == 401) {
                return response()->json(['success_code' => 401, 'message' => "Unauthorized Access!"]);
                exit();
            }

            $user_id = $request->user()->user_id;
	
            $RewardingActionData =  RewardingAction::get();
		
            if (!empty($RewardingActionData)) {
                return response()->json(['status' => 200, 'message' => "Rewarding Action Data Get Successfully.", 'data' => $RewardingActionData]);
            } else {
                return response()->json(['status' => 401, 'message' => "No Data Found.",'data'=>[]]);
            }
        } catch (\Exception $e) {
            Log::info($e->getMessage() . ', ' . basename((parse_url($e->getFile()))['path']) . '_line: ' . $e->getLine());
            return response()->json(['success_code' => 401, 'response_code' => 0, 'response_message' => "Something went wrong. Please try again."]);
        }
	}

    public function addCoin(Request $request)
    {
        try {
            
            $user_id = $request->user()->user_id;

            if (empty($user_id)) {
                $msg = "user id is required";
                return response()->json(['success_code' => 401, 'response_code' => 0, 'response_message' => $msg]);
            }

            $headers = $request->headers->all();
            
            $verify_request_base = Admin::verify_request_base($headers);

            if (isset($verify_request_base['status']) && $verify_request_base['status'] == 401) {
                return response()->json(['success_code' => 401, 'message' => "Unauthorized Access!"]);
                exit();
            }

            $rules = [
                'rewarding_action_id' => 'required',
            ];
    
            $validator = Validator::make($request->all(), $rules);
    
            if ($validator->fails()) {
                $messages = $validator->errors()->all();
                $msg = $messages[0];
                return response()->json(['status' => 401, 'message' => $msg]);
            }
            $rewarding_action_id = $request->get('rewarding_action_id');

            $coinData =  RewardingAction::where('rewarding_action_id', $rewarding_action_id)->first();
            $coin = $coinData['coin'];
            
            if($rewarding_action_id == 1)
            {
                $insert_coin = User::where('user_id', $user_id)->increment('spen_in_app',$coin);
            }
            elseif($rewarding_action_id == 2)
            {
                $insert_coin = User::where('user_id', $user_id)->increment('check_in',$coin);
            }
            elseif($rewarding_action_id == 3)
            {
                $insert_coin = User::where('user_id', $user_id)->increment('upload_video',$coin);
            }
            elseif($rewarding_action_id == 4)
            {
                $insert_coin = User::where('user_id', $user_id)->increment('from_fans',$coin);
            }
            elseif($rewarding_action_id == 5)
            {
                $insert_coin = User::where('user_id', $user_id)->increment('purchased',$coin);
            }
            $wallet_update = User::where('user_id', $user_id)->increment('my_wallet',$coin);

            $total_received = User::where('user_id', $user_id)->increment('total_received',$coin); 
            
            if ($insert_coin) {

                return response()->json(['status' => 200, 'message' => "Coin Added Successfully."]);
            } else {
                return response()->json(['status' => 401, 'message' => "Error While Add Coin."]);
            }    
            
        } catch (\Exception $e) {
            Log::info($e->getMessage() . ', ' . basename((parse_url($e->getFile()))['path']) . '_line: ' . $e->getLine());
            return response()->json(['status' => 401, 'message' => "Something went wrong. Please try again."]);
        }
    }
   
    public function sendCoin(Request $request)
    {
        try {
            
            $user_id = $request->user()->user_id;
            $full_name = $request->user()->full_name;

            if (empty($user_id)) {
                $msg = "user id is required";
                return response()->json(['success_code' => 401, 'response_code' => 0, 'response_message' => $msg]);
            }

            $headers = $request->headers->all();
            
            $verify_request_base = Admin::verify_request_base($headers);

            if (isset($verify_request_base['status']) && $verify_request_base['status'] == 401) {
                return response()->json(['success_code' => 401, 'message' => "Unauthorized Access!"]);
                exit();
            }

            $rules = [
                'to_user_id' => 'required',
                'coin' => 'required',
            ];
    
            $validator = Validator::make($request->all(), $rules);
    
            if ($validator->fails()) {
                $messages = $validator->errors()->all();
                $msg = $messages[0];
                return response()->json(['status' => 401, 'message' => $msg]);
            }
            $to_user_id = $request->get('to_user_id');
            $coin = $request->get('coin');

            $userData =  User::select('my_wallet','spen_in_app','check_in','upload_video','from_fans','purchased')->where('user_id', $user_id)->first();
            $wallet = $userData['my_wallet'];
            
            if($wallet >= $coin)
                {
                    $count_update = User::where('user_id', $user_id)->where('my_wallet', '>', $coin)->decrement('my_wallet',$coin);
                    $total_send = User::where('user_id', $user_id)->increment('total_send',$coin); 

                    $wallet_update = User::where('user_id', $to_user_id)->increment('from_fans',$coin);
                    $wallet_update = User::where('user_id', $to_user_id)->increment('my_wallet',$coin);

                    $total_received = User::where('user_id', $to_user_id)->increment('total_received',$coin);

                    $noti_user_id = $to_user_id;

                    $userData =  User::where('user_id',$noti_user_id)->first();
                    $platform = $userData['platform'];
                    $device_token = $userData['device_token'];
                    $message = $full_name.' sent you '.$coin.' Stars';

                    $notificationdata = array(
                        'sender_user_id'=>$user_id,
                        'received_user_id'=>$noti_user_id,
                        'notification_type'=>4,
                        'item_id'=>$user_id,
                        'message'=>$message,
                    );

                    Notification::insert($notificationdata);
                    $notification_title = "Shortzz";
                    $is_send = Common::send_push($device_token,$notification_title,$message,$platform);
                    
                    return response()->json(['status' => 200, 'message' => "Coin Send Successfully."]);
                }
                else
                {
                    return response()->json(['status' => 401, 'message' => "You have Insufficient Wallet Balance."]);
                }
            
        } catch (\Exception $e) {
            Log::info($e->getMessage() . ', ' . basename((parse_url($e->getFile()))['path']) . '_line: ' . $e->getLine());
            return response()->json(['status' => 401, 'message' => "Something went wrong. Please try again."]);
        }
    }

    public function purchaseCoin(Request $request)
    {
        try {
            
            $user_id = $request->user()->user_id;
            $full_name = $request->user()->full_name;

            if (empty($user_id)) {
                $msg = "user id is required";
                return response()->json(['success_code' => 401, 'response_code' => 0, 'response_message' => $msg]);
            }

            $headers = $request->headers->all();
            
            $verify_request_base = Admin::verify_request_base($headers);

            if (isset($verify_request_base['status']) && $verify_request_base['status'] == 401) {
                return response()->json(['success_code' => 401, 'message' => "Unauthorized Access!"]);
                exit();
            }

            $rules = [
                'coin' => 'required',
            ];
    
            $validator = Validator::make($request->all(), $rules);
    
            if ($validator->fails()) {
                $messages = $validator->errors()->all();
                $msg = $messages[0];
                return response()->json(['status' => 401, 'message' => $msg]);
            }

            $coin = $request->get('coin');

            $count_update = User::where('user_id', $user_id)->increment('purchased',$coin); 
            $wallet_update = User::where('user_id', $user_id)->increment('my_wallet',$coin);
            $total_received = User::where('user_id', $user_id)->increment('total_received',$coin);
           
            return response()->json(['status' => 200, 'message' => "Coin Purchased Successfully."]);
            
        } catch (\Exception $e) {
            Log::info($e->getMessage() . ', ' . basename((parse_url($e->getFile()))['path']) . '_line: ' . $e->getLine());
            return response()->json(['status' => 401, 'message' => "Something went wrong. Please try again."]);
        }
    }

    public function getMyWalletCoin(Request $request)
    {
        try {
            
            $user_id = $request->user()->user_id;

            if (empty($user_id)) {
                $msg = "user id is required";
                return response()->json(['success_code' => 401, 'response_code' => 0, 'response_message' => $msg]);
            }

            $headers = $request->headers->all();
            
            $verify_request_base = Admin::verify_request_base($headers);

            if (isset($verify_request_base['status']) && $verify_request_base['status'] == 401) {
                return response()->json(['success_code' => 401, 'message' => "Unauthorized Access!"]);
                exit();
            }

            $data = User::select('total_received','total_send','my_wallet','spen_in_app','check_in','upload_video','from_fans','purchased')->where('user_id', $user_id)->first(); 
           
            if (!empty($data)) {
                return response()->json(['status' => 200, 'message' => "My Wallet Data Get Successfully.", 'data' => $data]);
            } else {
                return response()->json(['status' => 401, 'message' => "No Data Found.",'data'=>$data]);
            }            
        } catch (\Exception $e) {
            Log::info($e->getMessage() . ', ' . basename((parse_url($e->getFile()))['path']) . '_line: ' . $e->getLine());
            return response()->json(['status' => 401, 'message' => "Something went wrong. Please try again."]);
        }
    }

    public function getCoinPlanList(Request $request)
    {
        try {
            
            $user_id = $request->user()->user_id;

            if (empty($user_id)) {
                $msg = "user id is required";
                return response()->json(['success_code' => 401, 'response_code' => 0, 'response_message' => $msg]);
            }

            $headers = $request->headers->all();
            
            $verify_request_base = Admin::verify_request_base($headers);

            if (isset($verify_request_base['status']) && $verify_request_base['status'] == 401) {
                return response()->json(['success_code' => 401, 'message' => "Unauthorized Access!"]);
                exit();
            }

            $data = CoinPlan::get(); 
           
            if (!empty($data)) {
                return response()->json(['status' => 200, 'message' => "Coin Plan Data Get Successfully.", 'data' => $data]);
            } else {
                return response()->json(['status' => 401, 'message' => "No Data Found.",'data'=>$data]);
            }            
        } catch (\Exception $e) {
            Log::info($e->getMessage() . ', ' . basename((parse_url($e->getFile()))['path']) . '_line: ' . $e->getLine());
            return response()->json(['status' => 401, 'message' => "Something went wrong. Please try again."]);
        }
    }

    public function redeemRequest(Request $request)
    {
        try {
            
            $user_id = $request->user()->user_id;
            $full_name = $request->user()->full_name;

            if (empty($user_id)) {
                $msg = "user id is required";
                return response()->json(['success_code' => 401, 'response_code' => 0, 'response_message' => $msg]);
            }

            $headers = $request->headers->all();
            
            $verify_request_base = Admin::verify_request_base($headers);

            if (isset($verify_request_base['status']) && $verify_request_base['status'] == 401) {
                return response()->json(['success_code' => 401, 'message' => "Unauthorized Access!"]);
                exit();
            }

            $rules = [
                'amount' => 'required',
                'redeem_request_type' => 'required',
                'account' => 'required',
            ];
    
            $validator = Validator::make($request->all(), $rules);
    
            if ($validator->fails()) {
                $messages = $validator->errors()->all();
                $msg = $messages[0];
                return response()->json(['status' => 401, 'message' => $msg]);
            }
            $coin = $request->get('coin') ? $request->get('coin') : 0;
            $amount = $request->get('amount');
            $redeem_request_type = $request->get('redeem_request_type');
            $account = $request->get('account');

            $data = array('redeem_request_type'=>$redeem_request_type,'account'=>$account,'amount'=>$amount,'user_id'=>$user_id);
            $insert = RedeemRequest::insert($data);

            $update_data = array(
                'total_received'=>0,
                'total_send'=>0,
                'my_wallet'=>0,
                'spen_in_app'=>0,
                'check_in'=>0,
                'upload_video'=>0,
                'from_fans'=>0,
                'purchased'=>0
            );
                // $total_received = User::where('user_id', $user_id)->where('total_received', '>', $coin)->decrement('total_received',$coin);
                // $total_send = User::where('user_id', $user_id)->where('total_send', '>', $coin)->decrement('total_send',$coin); 
                // $wallet_update = User::where('user_id', $user_id)->where('my_wallet', '>', $coin)->decrement('my_wallet',$coin);
                // $spen_in_app_update = User::where('user_id', $user_id)->where('spen_in_app', '>', $coin)->decrement('spen_in_app',$coin);
                // $check_in_update = User::where('user_id', $user_id)->where('check_in', '>', $coin)->decrement('check_in',$coin);
                // $upload_video_update = User::where('user_id', $user_id)->where('upload_video', '>', $coin)->decrement('upload_video',$coin);
                // $from_fans_update = User::where('user_id', $user_id)->where('from_fans', '>', $coin)->decrement('from_fans',$coin);
                // $purchased_update = User::where('user_id', $user_id)->where('purchased', '>', $coin)->decrement('purchased',$coin);


            $count_update = User::where('user_id', $user_id)->update($update_data); 
            if($insert){
                return response()->json(['status' => 200, 'message' => "Redeem Request Successfully."]);
            }else{
                return response()->json(['status' => 401, 'message' => "Redeem Request Failed."]);
            }            
            
        } catch (\Exception $e) {
            Log::info($e->getMessage() . ', ' . basename((parse_url($e->getFile()))['path']) . '_line: ' . $e->getLine());
            return response()->json(['status' => 401, 'message' => "Something went wrong. Please try again."]);
        }
    }
}
