<?php

namespace App\Http\Controllers\admin;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Redirect;
use URL;
use Hash;
use File;
use Session;
use DB;
use App\Admin;
use App\RewardingAction;

class RewardingActionController extends Controller
{

    public function viewListRewardingAction()
	{
        $total_rewarding_action = RewardingAction::count();
		return view('admin.rewarding_action.rewarding_action_list')->with('total_rewarding_action',$total_rewarding_action);
    }

	public function updateRewardingAction(Request $request)
	{
		$rewarding_action_id = $request->input('rewarding_action_id');
		$action_name = $request->input('action_name');
		$coin = $request->input('coin');
        $data['action_name'] = $action_name;
		$data['coin'] = $coin;
		$result = RewardingAction::where('rewarding_action_id',$rewarding_action_id)->update($data);
		
		if($result){
			$response['success'] = 1;
			$response['message'] = "Successfully Update Rewarding Action";
		} else {
			$response['success'] = 0;
			$response['message'] = "Error While Update Rewarding Action";
		}
		echo json_encode($response);
	}

	public function showRewardingActionList(Request $request)
    {

		$columns = array( 
            0=>'action_name',
            1=>'coin',
		);

		$limit = $request->input('length');
		$start = $request->input('start');
		$order = $columns[$request->input('order.0.column')];
		$dir = $request->input('order.0.dir');

		if(empty($request->input('search.value')))
		{      
			$CoinPlanData = RewardingAction::offset($start)
					->limit($limit)
					->orderBy($order,$dir)
					->get();
			$totalData = $totalFiltered = RewardingAction::count();
		}
		else {
			$search = $request->input('search.value'); 
			$CoinPlanData =  RewardingAction::where('rewarding_action_id','LIKE',"%{$search}%")
							->orWhere('action_name', 'LIKE',"%{$search}%")
							->orWhere('coin', 'LIKE',"%{$search}%")
							->offset($start)
							->limit($limit)
							->orderBy($order,$dir)
							->get();

				$totalFiltered = RewardingAction::where('rewarding_action_id','LIKE',"%{$search}%")
						->orWhere('action_name', 'LIKE',"%{$search}%")
						->orWhere('coin', 'LIKE',"%{$search}%")
						->count();
		}

		$data = array();
		if(!empty($CoinPlanData))
		{
			foreach ($CoinPlanData as $rows)
			{
				if(Session::get('admin_id') == 2){ 
					$disabled = "disabled";
				}else{
					$disabled = "";
				}
				$data[]= array(
					$rows->action_name,
					$rows->coin,
					'<a data-toggle="modal" data-target="#updateRewardingActionModal" data-id="'.$rows->rewarding_action_id.'"
					data-name="'.$rows->action_name.'" data-coin="'.$rows->coin.'" class="settings UpdateCoinPlan" title="Edit RewardingAction" data-toggle="tooltip" data-original-title="Edit RewardingAction" '.$disabled.'><i class="i-cl-3 fas fa-edit col-blue font-20 pointer p-l-5 p-r-5"></i></a>',
				);  
			}
		}

		$json_data = array(
			"draw"            => intval($request->input('draw')),  
			"recordsTotal"    => intval($totalData),  
			"recordsFiltered" => intval($totalFiltered), 
			"data"            => $data   
			);

		echo json_encode($json_data); 
        exit();
	}
}
