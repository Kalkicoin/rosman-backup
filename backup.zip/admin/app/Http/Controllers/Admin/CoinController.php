<?php

namespace App\Http\Controllers\admin;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Redirect;
use URL;
use Hash;
use Session;
use DB;
use File;
use App\Admin;
use App\CoinRate;
use App\CoinPlan;

class CoinController extends Controller
{

	public function viewCoinRateEdit()
	{
        $coin_rate = CoinRate::where('coin_rate_id',1)->first();
		return view('admin.coin.coin_rate')->with('coin_rate',$coin_rate);
    }

	public function updateCoinRate(Request $request)
	{
		$coin_rate_id = $request->input('coin_rate_id');
		$usd_rate = $request->input('usd_rate');
        $data['usd_rate'] = $usd_rate;
		$result = CoinRate::where('coin_rate_id',$coin_rate_id)->update($data);
		
		if($result){
			$response['success'] = 1;
			$response['message'] = "Successfully Update Coin Rate";
		} else {
			$response['success'] = 0;
			$response['message'] = "Error While Update Coin Rate";
		}
		echo json_encode($response);
	}


	public function viewListCoinPlan()
	{
		$total_coin_plan = CoinPlan::count();
		return view('admin.coin.coin_plan_list')->with('total_coin_plan',$total_coin_plan);
    }

	
	public function addUpdateCoinPlan(Request $request)
	{
		$coin_plan_id = $request->input('coin_plan_id');
		$coin_plan_name = $request->input('coin_plan_name');
		$coin_plan_description = $request->input('coin_plan_description');
		$coin_plan_price = $request->input('coin_plan_price');
		$coin_amount = $request->input('coin_amount');
		$playstore_product_id = $request->input('playstore_product_id');
		$appstore_product_id = $request->input('appstore_product_id');

		$data['coin_plan_name'] = $coin_plan_name;
		$data['coin_plan_description'] = $coin_plan_description;
		$data['coin_plan_price'] = $coin_plan_price;
		$data['coin_amount'] = $coin_amount;
		$data['playstore_product_id'] = $playstore_product_id;
		$data['appstore_product_id'] = $appstore_product_id;

		if(!empty($coin_plan_id)){
			$result =  CoinPlan::where('coin_plan_id',$coin_plan_id)->update($data);
			$msg = "Update";
			$response['flag'] = 2;
		}else{
			$result =  CoinPlan::insert($data);
			$msg = "Add";
			$response['flag'] = 1;
		}
		$total_coin_plan = CoinPlan::count();
		if ($result) {
			$response['success'] = 1;
			$response['message'] = "Successfully ".$msg." Coin Plan";
			$response['total_coin_plan'] = $total_coin_plan;
		} else {
			$response['success'] = 0;
			$response['message'] = "Error While ".$msg." Coin Plan";
			$response['total_coin_plan'] = 0;
		}
		echo json_encode($response);
	}

	public function deleteCoinPlan(Request $request){

		$coin_plan_id = $request->input('coin_plan_id');
		$result =  CoinPlan::where('coin_plan_id',$coin_plan_id)->delete();
		$total_coin_plan = CoinPlan::count();
		if ($result) {
			$response['success'] = 1;
			$response['total_coin_plan'] = $total_coin_plan;
		} else {
			$response['success'] = 0;
			$response['total_coin_plan'] = 0;
		}
		echo json_encode($response);

	}

	public function showCoinPlanList(Request $request)
    {

		$columns = array( 
            0=>'coin_plan_name',
            1=>'coin_plan_description',
            2=>'coin_plan_price',
            3=>'coin_amount',
			4=>'playstore_product_id',
			5=>'appstore_product_id',
			6=>'created_at'
		);

		$limit = $request->input('length');
		$start = $request->input('start');
		$order = $columns[$request->input('order.0.column')];
		$dir = $request->input('order.0.dir');

		if(empty($request->input('search.value')))
		{      
			$CoinPlanData = CoinPlan::offset($start)
					->limit($limit)
					->orderBy($order,$dir)
					->get();
			$totalData = $totalFiltered = CoinPlan::count();
		}
		else {
			$search = $request->input('search.value'); 
			$CoinPlanData =  CoinPlan::where('coin_plan_id','LIKE',"%{$search}%")
							->orWhere('coin_plan_name', 'LIKE',"%{$search}%")
							->orWhere('coin_plan_description', 'LIKE',"%{$search}%")
							->orWhere('coin_plan_price', 'LIKE',"%{$search}%")
							->orWhere('coin_amount', 'LIKE',"%{$search}%")
							->orWhere('playstore_product_id', 'LIKE',"%{$search}%")
							->orWhere('appstore_product_id', 'LIKE',"%{$search}%")
							->orWhere('created_at', 'LIKE',"%{$search}%")
							->offset($start)
							->limit($limit)
							->orderBy($order,$dir)
							->get();

				$totalFiltered = CoinPlan::where('coin_plan_id','LIKE',"%{$search}%")
						->orWhere('coin_plan_name', 'LIKE',"%{$search}%")
						->orWhere('coin_plan_description', 'LIKE',"%{$search}%")
						->orWhere('coin_plan_price', 'LIKE',"%{$search}%")
						->orWhere('coin_amount', 'LIKE',"%{$search}%")
						->orWhere('playstore_product_id', 'LIKE',"%{$search}%")
						->orWhere('appstore_product_id', 'LIKE',"%{$search}%")
						->orWhere('created_at', 'LIKE',"%{$search}%")
						->count();
		}

		$data = array();
		if(!empty($CoinPlanData))
		{
			foreach ($CoinPlanData as $rows)
			{

				if(Session::get('admin_id') == 2){ 
					$disabled = "disabled";
				}else{
					$disabled = "";
				}
 
				$data[]= array(
					$rows->coin_plan_name,
					$rows->coin_plan_description,
					$rows->coin_plan_price,
					$rows->coin_amount,
					$rows->playstore_product_id,
					$rows->appstore_product_id,
					date('Y-m-d',strtotime($rows->created_at)),
					'<a data-toggle="modal" data-target="#coinPlanModal" data-id="'.$rows->coin_plan_id.'"
					data-name="'.$rows->coin_plan_name.'" data-description="'.$rows->coin_plan_description.'" data-price="'.$rows->coin_plan_price.'" data-amount="'.$rows->coin_amount.'" data-playstore_product_id="'.$rows->playstore_product_id.'" data-appstore_product_id="'.$rows->appstore_product_id.'" class="settings UpdateCoinPlan" title="Edit CoinPlan" data-toggle="tooltip" data-original-title="Edit CoinPlan" '.$disabled.'><i class="i-cl-3 fas fa-edit col-blue font-20 pointer p-l-5 p-r-5"></i></a>
					<a class="delete" id="deleteCoinPlan" data-id="'.$rows->coin_plan_id.'" '.$disabled.'><i class="fas fa-trash text-danger font-20 pointer p-l-5 p-r-5"></i></a>',
				);  
			}
		}

		$json_data = array(
			"draw"            => intval($request->input('draw')),  
			"recordsTotal"    => intval($totalData),  
			"recordsFiltered" => intval($totalFiltered), 
			"data"            => $data   
			);

		echo json_encode($json_data); 
        exit();
	}
}


 